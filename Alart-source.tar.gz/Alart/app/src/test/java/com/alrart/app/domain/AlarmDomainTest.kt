package com.alrart.app.domain

import com.alrart.app.data.AlarmEntity
import com.alrart.app.data.AlarmEventEntity
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneId

class AlarmDomainTest {
    @Test fun nextOneTimeAlarmMovesToTomorrowWhenTimePassed() {
        val alarm = AlarmEntity(hour = 7, minute = 30)
        val now = LocalDateTime.of(2026, 11, 15, 8, 0)
        val result = AlarmTime.nextOccurrence(alarm, now, ZoneId.of("UTC"))!!
        assertEquals(LocalDateTime.of(2026, 11, 16, 7, 30).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli(), result)
    }

    @Test fun repeatingAlarmFindsNextMatchingWeekday() {
        val alarm = AlarmEntity(hour = 7, minute = 0, repeatDays = "1,3,5")
        val now = LocalDateTime.of(2026, 11, 15, 9, 0) // Sunday
        val result = AlarmTime.nextOccurrence(alarm, now, ZoneId.of("UTC"))!!
        assertEquals(LocalDateTime.of(2026, 11, 16, 7, 0).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli(), result)
    }


    @Test fun persistedSnoozeTriggerTakesPriorityOverRegularTime() {
        val zone = ZoneId.of("UTC")
        val now = LocalDateTime.of(2026, 11, 15, 8, 0)
        val snoozeAt = now.plusMinutes(5).atZone(zone).toInstant().toEpochMilli()
        val alarm = AlarmEntity(hour = 7, minute = 30, nextTriggerAt = snoozeAt)
        assertEquals(snoozeAt, AlarmTime.nextOccurrence(alarm, now, zone))
    }

    @Test fun specificDateAlarmOnlySchedulesOnItsSelectedDate() {
        val zone = ZoneId.of("UTC")
        val alarm = AlarmEntity(hour = 7, minute = 30, specificDate = "2026-11-16")
        val before = LocalDateTime.of(2026, 11, 15, 23, 0)
        val expected = LocalDateTime.of(2026, 11, 16, 7, 30).atZone(zone).toInstant().toEpochMilli()
        assertEquals(expected, AlarmTime.nextOccurrence(alarm, before, zone))
        assertNull(AlarmTime.nextOccurrence(alarm, LocalDateTime.of(2026, 11, 16, 8, 0), zone))
    }

    @Test fun jalaliDatesRoundTripAcrossNewYearAndLeapDay() {
        val dates = listOf(
            java.time.LocalDate.of(2026, 3, 21),
            java.time.LocalDate.of(2026, 11, 15),
            java.time.LocalDate.of(2024, 2, 29)
        )
        dates.forEach { date ->
            val jalali = JalaliDate.fromGregorian(date)
            assertEquals(date, jalali.toGregorian())
        }
        assertEquals(java.time.LocalDate.of(2026, 3, 21), JalaliDate(1405, 1, 1).toGregorian())
    }

    @Test fun expiredPersistedTriggerFallsBackToNextRegularOccurrence() {
        val zone = ZoneId.of("UTC")
        val now = LocalDateTime.of(2026, 11, 15, 8, 0)
        val expired = now.minusMinutes(10).atZone(zone).toInstant().toEpochMilli()
        val alarm = AlarmEntity(hour = 9, minute = 15, nextTriggerAt = expired)
        val expected = LocalDateTime.of(2026, 11, 15, 9, 15).atZone(zone).toInstant().toEpochMilli()
        assertEquals(expected, AlarmTime.nextOccurrence(alarm, now, zone))
    }

    @Test fun soundVolumeDefaultsToFullLevel() {
        assertEquals(100, AlarmEntity(hour = 7, minute = 0).soundVolume)
    }

    @Test fun acceptsPersianAndArabicNumerals() {
        assertTrue(MathAnswer.isCorrect("۱۲۳", 123))
        assertTrue(MathAnswer.isCorrect("١٢٣", 123))
        assertFalse(MathAnswer.isCorrect("۱۲۴", 123))
    }

    @Test fun snoozedRingCountsAsCompletedDismissalSession() {
        val events = listOf(
            AlarmEventEntity(alarmId = 7, eventType = "RING", occurredAt = 10_000, dismissedAt = 40_000),
            AlarmEventEntity(alarmId = 7, eventType = "SNOOZE", occurredAt = 40_000),
            AlarmEventEntity(alarmId = 7, eventType = "RING", occurredAt = 340_000)
        )
        val stats = Statistics.from(events)
        assertEquals(2, stats.ringCount)
        assertEquals(1, stats.snoozeCount)
        assertEquals(30_000L, stats.averageDismissMillis)
    }

    @Test fun invalidSolarHijriDatesAreRejected() {
        assertNull(JalaliDate.parse("1405/12/31"))
        assertNull(JalaliDate.parse("1405/13/01"))
        assertEquals(java.time.LocalDate.of(2026, 3, 21), JalaliDate.parse("۱۴۰۵/۰۱/۰۱")!!.toGregorian())
    }

    @Test fun statisticsOnlyUseRecordedEvents() {
        val events = listOf(
            AlarmEventEntity(alarmId = 1, eventType = "RING", occurredAt = 1_000, dismissedAt = 6_000),
            AlarmEventEntity(alarmId = 1, eventType = "SNOOZE", occurredAt = 2_000),
            AlarmEventEntity(alarmId = 2, eventType = "RING", occurredAt = 10_000),
            AlarmEventEntity(alarmId = 3, eventType = "SET", occurredAt = 500)
        )
        val stats = Statistics.from(events)
        assertEquals(1, stats.setCount)
        assertEquals(2, stats.ringCount)
        assertEquals(1, stats.snoozeCount)
        assertEquals(5_000L, stats.averageDismissMillis)
    }
}
