package com.alrart.app.alarm

import androidx.glance.appwidget.updateAll
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import com.alrart.app.data.AlarmEventEntity
import com.alrart.app.data.AlartDatabase
import com.alrart.app.widget.AlartWidget
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(AlarmReceiver.EXTRA_ALARM_ID, -1L)
        if (id < 0) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AlartDatabase.get(context).alarmDao()
                val alarm = dao.get(id) ?: return@launch
                when (intent.action) {
                    ACTION_STOP -> {
                        context.stopService(Intent(context, AlarmSoundService::class.java))
                        val now = System.currentTimeMillis()
                        // Close the active ring event once; repeated notification taps must not
                        // create misleading dismissal durations.
                        dao.markLatestRingDismissed(id, now)
                        dao.addEvent(AlarmEventEntity(alarmId = id, eventType = "DISMISS", occurredAt = now))
                        NotificationManagerCompat.from(context).cancel(id.toInt())
                        try { AlartWidget().updateAll(context) } catch (_: Exception) { }
                    }
                    ACTION_SNOOZE -> {
                        context.stopService(Intent(context, AlarmSoundService::class.java))
                        val now = System.currentTimeMillis()
                        // Snoozing ends this ringing session, so it is part of ring-to-dismissal
                        // statistics just like pressing Stop.
                        dao.markLatestRingDismissed(id, now)
                        dao.setEnabled(id, true)
                        dao.addEvent(AlarmEventEntity(alarmId = id, eventType = "SNOOZE", occurredAt = now))
                        val manager = context.getSystemService(AlarmManager::class.java)
                        val triggerAt = System.currentTimeMillis() + alarm.snoozeMinutes * 60_000L
                        val alarmIntent = Intent(context, AlarmReceiver::class.java).apply {
                            putExtra(AlarmReceiver.EXTRA_ALARM_ID, id)
                            putExtra(AlarmReceiver.EXTRA_EXPECTED_TRIGGER, triggerAt)
                            putExtra(AlarmReceiver.EXTRA_SOUND_URI, alarm.soundUri)
                            putExtra(AlarmReceiver.EXTRA_VIBRATION, alarm.vibration)
                            putExtra(AlarmReceiver.EXTRA_SOUND_VOLUME, alarm.soundVolume)
                            putExtra(AlarmReceiver.EXTRA_ALARM_TITLE, alarm.title)
                        }
                        val pi = PendingIntent.getBroadcast(context, id.toInt(), alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                        dao.setNextTrigger(id, triggerAt)
                        try {
                            if (android.os.Build.VERSION.SDK_INT < 31 || manager.canScheduleExactAlarms()) {
                                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                            } else {
                                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                            }
                        } catch (_: SecurityException) {
                            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                        }
                        NotificationManagerCompat.from(context).cancel(id.toInt())
                        try { AlartWidget().updateAll(context) } catch (_: Exception) { }
                    }
                }
            } finally { pending.finish() }
        }
    }
    companion object {
        const val ACTION_STOP = "com.alrart.app.action.STOP"
        const val ACTION_SNOOZE = "com.alrart.app.action.SNOOZE"
    }
}
