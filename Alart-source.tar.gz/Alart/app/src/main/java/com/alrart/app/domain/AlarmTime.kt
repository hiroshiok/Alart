package com.alrart.app.domain

import com.alrart.app.data.AlarmEntity
import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.ZoneId

object AlarmTime {
    /** Returns the next local occurrence. Empty repeatDays means the next occurrence only. */
    fun nextOccurrence(alarm: AlarmEntity, now: LocalDateTime, zone: ZoneId = ZoneId.systemDefault()): Long? {
        if (!alarm.enabled) return null
        val nowMillis = now.atZone(zone).toInstant().toEpochMilli()
        alarm.nextTriggerAt?.takeIf { it > nowMillis }?.let { return it }
        alarm.specificDate?.let { rawDate ->
            val date = runCatching { java.time.LocalDate.parse(rawDate) }.getOrNull() ?: return null
            if (date.isBefore(now.toLocalDate())) return null
            val candidate = date.atTime(alarm.hour, alarm.minute)
            if (candidate <= now) return null
            return candidate.atZone(zone).toInstant().toEpochMilli()
        }
        val days = alarm.repeatDays.split(',').mapNotNull { it.toIntOrNull() }.toSet()
        for (offset in 0..7) {
            val candidateDate = now.toLocalDate().plusDays(offset.toLong())
            val candidate = candidateDate.atTime(alarm.hour, alarm.minute)
            if (candidate <= now) continue
            if (days.isEmpty() || candidate.dayOfWeek.value in days) {
                return candidate.atZone(zone).toInstant().toEpochMilli()
            }
        }
        return null
    }

    fun parseRepeatDays(value: String): Set<DayOfWeek> = value.split(',').mapNotNull { it.toIntOrNull() }
        .filter { it in 1..7 }.map { DayOfWeek.of(it) }.toSet()
}
