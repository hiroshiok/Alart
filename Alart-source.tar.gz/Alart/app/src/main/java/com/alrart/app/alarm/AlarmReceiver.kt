package com.alrart.app.alarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.NotificationCompat.CATEGORY_ALARM
import androidx.core.app.NotificationCompat.PRIORITY_MAX
import androidx.core.app.NotificationCompat.VISIBILITY_PUBLIC
import com.alrart.app.R
import com.alrart.app.data.AlarmEventEntity
import com.alrart.app.data.AlartDatabase
import com.alrart.app.ui.RingingActivity
import com.alrart.app.widget.AlartWidget
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(EXTRA_ALARM_ID, -1L)
        if (id < 0) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AlartDatabase.get(context).alarmDao()
                val alarm = dao.get(id) ?: return@launch
                if (!alarm.enabled) return@launch
                val expectedTrigger = intent.getLongExtra(EXTRA_EXPECTED_TRIGGER, 0L)
                // Ignore deliveries from an older schedule after edit/disable/reschedule.
                if (expectedTrigger > 0L && alarm.nextTriggerAt != expectedTrigger) return@launch
                val soundServiceStarted = try {
                    val playback = Intent(context, AlarmSoundService::class.java).apply {
                        action = AlarmSoundService.ACTION_START
                        putExtra(EXTRA_ALARM_ID, id)
                        putExtra(EXTRA_ALARM_TITLE, alarm.title)
                        putExtra(EXTRA_SOUND_URI, alarm.soundUri)
                        putExtra(EXTRA_VIBRATION, alarm.vibration)
                        putExtra(EXTRA_SOUND_VOLUME, alarm.soundVolume)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(playback)
                    else context.startService(playback)
                    true
                } catch (_: Exception) { false }
                dao.addEvent(AlarmEventEntity(alarmId = id, eventType = "RING", occurredAt = System.currentTimeMillis()))
                if (alarm.repeatDays.isBlank()) {
                    dao.setEnabled(id, false)
                    dao.setNextTrigger(id, null)
                } else {
                    val next = AlarmScheduler(context).schedule(alarm.copy(nextTriggerAt = null))
                    dao.setNextTrigger(id, next)
                }
                try { AlartWidget().updateAll(context) } catch (_: Exception) { }
                val channelId = "alart_alarm_v2_${id}_${alarm.soundUri?.hashCode() ?: 0}"
                val nm = context.getSystemService(NotificationManager::class.java)
                if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
                    NotificationChannel(channelId, context.getString(R.string.alarms), NotificationManager.IMPORTANCE_HIGH).apply {
                        description = context.getString(R.string.alarm_channel_description)
                        // Playback and vibration are handled by AlarmSoundService. The
                        // notification channel must remain silent to avoid double ringing.
                        setSound(null, null)
                        enableVibration(false)
                    })
                val open = PendingIntent.getActivity(context, id.toInt(), Intent(context, RingingActivity::class.java)
                    .putExtra(EXTRA_ALARM_ID, id)
                    .putExtra(EXTRA_SOUND_SERVICE_STARTED, soundServiceStarted), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val stop = PendingIntent.getBroadcast(context, id.toInt() + 100000, Intent(context, AlarmActionReceiver::class.java).setAction(AlarmActionReceiver.ACTION_STOP).putExtra(EXTRA_ALARM_ID, id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val snooze = PendingIntent.getBroadcast(context, id.toInt() + 200000, Intent(context, AlarmActionReceiver::class.java).setAction(AlarmActionReceiver.ACTION_SNOOZE).putExtra(EXTRA_ALARM_ID, id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val notification = NotificationCompat.Builder(context, channelId)
                    .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                    .setContentTitle(alarm.title.ifBlank { context.getString(R.string.app_name) })
                    .setContentText("%02d:%02d".format(alarm.hour, alarm.minute))
                    .setCategory(CATEGORY_ALARM).setPriority(PRIORITY_MAX).setVisibility(VISIBILITY_PUBLIC)
                    .setContentIntent(open).setFullScreenIntent(open, true).setAutoCancel(false)
                    .apply {
                        // Math-protected alarms must be dismissed only from the challenge screen.
                        if (!alarm.mathEnabled) {
                            addAction(0, context.getString(R.string.snooze_action, alarm.snoozeMinutes), snooze)
                            addAction(0, context.getString(R.string.stop), stop)
                        }
                    }.build()
                try { NotificationManagerCompat.from(context).notify(id.toInt(), notification) } catch (_: SecurityException) { }
            } finally { pending.finish() }
        }
    }
    companion object {
        const val EXTRA_ALARM_ID = "alarm_id"
        const val EXTRA_EXPECTED_TRIGGER = "expected_trigger"
        const val EXTRA_SOUND_URI = "sound_uri"
        const val EXTRA_VIBRATION = "vibration"
        const val EXTRA_SOUND_VOLUME = "sound_volume"
        const val EXTRA_ALARM_TITLE = "alarm_title"
        const val EXTRA_SOUND_SERVICE_STARTED = "sound_service_started"
    }
}
