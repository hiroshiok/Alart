package com.alrart.app.alarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.alrart.app.R
import com.alrart.app.data.AlarmEventEntity
import com.alrart.app.data.AlartDatabase
import com.alrart.app.ui.RingingActivity
import com.alrart.app.widget.AlartWidget
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlin.math.abs

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(EXTRA_ALARM_ID, -1L)
        if (id < 0L) return
        AlarmDiagnostics.record(context, "RECEIVER_DELIVERED", "id=$id; expected=${intent.getLongExtra(EXTRA_EXPECTED_TRIGGER, 0L)}")

        val wakeLock = context.getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Alart:AlarmReceiver")
        runCatching { wakeLock.acquire(30_000L) }
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val dao = AlartDatabase.get(context).alarmDao()
                val alarm = dao.get(id)
                if (alarm == null) {
                    AlarmDiagnostics.record(context, "RECEIVER_NO_ALARM", "No database row for id=$id")
                    return@launch
                }
                if (!alarm.enabled) {
                    AlarmDiagnostics.record(context, "RECEIVER_DISABLED", "id=$id is disabled")
                    return@launch
                }

                val expectedTrigger = intent.getLongExtra(EXTRA_EXPECTED_TRIGGER, 0L)
                val storedTrigger = alarm.nextTriggerAt ?: 0L
                if (expectedTrigger > 0L && storedTrigger > 0L && abs(storedTrigger - expectedTrigger) > 1_000L) {
                    AlarmDiagnostics.record(context, "RECEIVER_STALE_SKIPPED", "expected=$expectedTrigger; stored=$storedTrigger")
                    return@launch
                }

                val playback = Intent(context, AlarmSoundService::class.java).apply {
                    action = AlarmSoundService.ACTION_START
                    putExtra(EXTRA_ALARM_ID, id)
                    putExtra(EXTRA_ALARM_TITLE, alarm.title)
                    putExtra(EXTRA_SOUND_URI, alarm.soundUri)
                    putExtra(EXTRA_VIBRATION, alarm.vibration)
                    putExtra(EXTRA_SOUND_VOLUME, alarm.soundVolume)
                }
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(playback)
                    else context.startService(playback)
                    AlarmDiagnostics.record(context, "SERVICE_START_REQUESTED", "id=$id")
                } catch (error: Exception) {
                    AlarmDiagnostics.record(context, "SERVICE_START_FAILED", "${error.javaClass.simpleName}: ${error.message}")
                }

                dao.addEvent(AlarmEventEntity(alarmId = id, eventType = "RING", occurredAt = System.currentTimeMillis()))
                if (alarm.repeatDays.isBlank()) {
                    dao.setEnabled(id, false)
                    dao.setNextTrigger(id, null)
                } else {
                    val next = AlarmScheduler(context).schedule(alarm.copy(nextTriggerAt = null))
                    dao.setNextTrigger(id, next)
                }

                runCatching { AlartWidget().updateAll(context) }
                postAlarmNotification(context, id, alarm)
                AlarmDiagnostics.record(context, "RING_FLOW_COMPLETED", "id=$id")
            } catch (error: Exception) {
                AlarmDiagnostics.record(context, "RECEIVER_ERROR", "${error.javaClass.simpleName}: ${error.message}")
            } finally {
                runCatching { if (wakeLock.isHeld) wakeLock.release() }
                pending.finish()
            }
        }
    }

    private fun postAlarmNotification(context: Context, id: Long, alarm: com.alrart.app.data.AlarmEntity) {
        val channelId = "alart_alarm_v4"
        val notificationManager = context.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(
                NotificationChannel(channelId, context.getString(R.string.alarms), NotificationManager.IMPORTANCE_HIGH).apply {
                    description = context.getString(R.string.alarm_channel_description)
                    setSound(null, null)
                    enableVibration(false)
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                }
            )
        }
        val open = PendingIntent.getActivity(
            context, id.toInt(), Intent(context, RingingActivity::class.java).putExtra(EXTRA_ALARM_ID, id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getBroadcast(
            context, id.toInt() + 100_000,
            Intent(context, AlarmActionReceiver::class.java).setAction(AlarmActionReceiver.ACTION_STOP).putExtra(EXTRA_ALARM_ID, id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val snooze = PendingIntent.getBroadcast(
            context, id.toInt() + 200_000,
            Intent(context, AlarmActionReceiver::class.java).setAction(AlarmActionReceiver.ACTION_SNOOZE).putExtra(EXTRA_ALARM_ID, id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(alarm.title.ifBlank { context.getString(R.string.app_name) })
            .setContentText("%02d:%02d".format(alarm.hour, alarm.minute))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .setOngoing(true)
            .setAutoCancel(false)
            .apply {
                if (!alarm.mathEnabled) {
                    addAction(0, context.getString(R.string.snooze_action, alarm.snoozeMinutes), snooze)
                    addAction(0, context.getString(R.string.stop), stop)
                }
            }
            .build()
        try {
            NotificationManagerCompat.from(context).notify(id.toInt(), notification)
            AlarmDiagnostics.record(context, "NOTIFICATION_POSTED", "id=$id")
        } catch (error: SecurityException) {
            AlarmDiagnostics.record(context, "NOTIFICATION_BLOCKED", error.message.orEmpty())
        }
    }

    companion object {
        const val ACTION_TRIGGER = "com.alrart.app.alarm.TRIGGER"
        const val EXTRA_ALARM_ID = "alarm_id"
        const val EXTRA_EXPECTED_TRIGGER = "expected_trigger"
        const val EXTRA_SOUND_URI = "sound_uri"
        const val EXTRA_VIBRATION = "vibration"
        const val EXTRA_SOUND_VOLUME = "sound_volume"
        const val EXTRA_ALARM_TITLE = "alarm_title"
    }
}
