package com.alrart.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AlarmDao {
    @Query("SELECT * FROM alarms ORDER BY hour, minute") fun observeAll(): Flow<List<AlarmEntity>>
    @Query("SELECT * FROM alarms WHERE enabled = 1") suspend fun enabled(): List<AlarmEntity>
    @Query("SELECT * FROM alarms WHERE id = :id LIMIT 1") suspend fun get(id: Long): AlarmEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(alarm: AlarmEntity): Long
    @Query("DELETE FROM alarms WHERE id = :id") suspend fun delete(id: Long)
    @Query("UPDATE alarms SET enabled = :enabled WHERE id = :id") suspend fun setEnabled(id: Long, enabled: Boolean)
    @Query("UPDATE alarms SET nextTriggerAt = :at WHERE id = :id") suspend fun setNextTrigger(id: Long, at: Long?)
    @Insert suspend fun addEvent(event: AlarmEventEntity)
    @Query("UPDATE alarm_events SET dismissedAt = :dismissedAt WHERE id = (SELECT id FROM alarm_events WHERE alarmId = :alarmId AND eventType = 'RING' AND dismissedAt IS NULL ORDER BY occurredAt DESC LIMIT 1)") suspend fun markLatestRingDismissed(alarmId: Long, dismissedAt: Long)
    @Query("SELECT * FROM alarm_events ORDER BY occurredAt DESC") fun observeEvents(): Flow<List<AlarmEventEntity>>
    @Query("SELECT COUNT(*) FROM alarm_events WHERE eventType = 'SNOOZE'") fun snoozeCount(): Flow<Int>
}
