package com.alrart.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.alartPreferences by preferencesDataStore(name = "alart_settings")

class SettingsStore(context: Context) {
    private val store = context.applicationContext.alartPreferences
    private val themeKey = stringPreferencesKey("theme_mode")
    private val fontKey = stringPreferencesKey("font_family")
    private val defaultVibrationKey = booleanPreferencesKey("default_vibration")
    private val defaultSnoozeKey = intPreferencesKey("default_snooze_minutes")
    private val defaultSoundKey = stringPreferencesKey("default_sound_uri")

    val themeMode: Flow<String> = store.data.map { it[themeKey] ?: "system" }
    val fontFamily: Flow<String> = store.data.map { it[fontKey] ?: "sans" }
    val defaultVibration: Flow<Boolean> = store.data.map { it[defaultVibrationKey] ?: true }
    val defaultSnoozeMinutes: Flow<Int> = store.data.map { (it[defaultSnoozeKey] ?: 5).coerceIn(1, 30) }
    val defaultSoundUri: Flow<String?> = store.data.map { it[defaultSoundKey] }

    suspend fun setThemeMode(mode: String) { store.edit { it[themeKey] = mode } }
    suspend fun setFontFamily(value: String) { store.edit { it[fontKey] = value } }
    suspend fun setDefaultVibration(value: Boolean) { store.edit { it[defaultVibrationKey] = value } }
    suspend fun setDefaultSnoozeMinutes(value: Int) { store.edit { it[defaultSnoozeKey] = value.coerceIn(1, 30) } }
    suspend fun setDefaultSoundUri(value: String?) {
        store.edit { preferences -> if (value == null) preferences.remove(defaultSoundKey) else preferences[defaultSoundKey] = value }
    }
}
