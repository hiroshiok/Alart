package com.alrart.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** Receives the user-requested 10-second test alarm through the same OS alarm pipeline. */
class AlarmTestReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmDiagnostics.record(context, "TEST_BROADCAST_RECEIVED", "OS delivered the test alarm")
        val playback = Intent(context, AlarmSoundService::class.java).apply {
            action = AlarmSoundService.ACTION_START
            putExtra(AlarmReceiver.EXTRA_ALARM_ID, TEST_ALARM_ID)
            putExtra(AlarmReceiver.EXTRA_ALARM_TITLE, context.getString(com.alrart.app.R.string.test_alarm))
            putExtra(AlarmReceiver.EXTRA_VIBRATION, true)
            putExtra(AlarmReceiver.EXTRA_SOUND_VOLUME, 100)
            putExtra(AlarmSoundService.EXTRA_TEST_MODE, true)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(playback)
            else context.startService(playback)
        } catch (error: Exception) {
            AlarmDiagnostics.record(context, "TEST_SERVICE_START_FAILED", "${error.javaClass.simpleName}: ${error.message}")
        }
    }

    companion object {
        const val TEST_ALARM_ID = 0L
        const val REQUEST_CODE = 784321
    }
}
