package com.alrart.app.data

import androidx.room.Entity
import androidx.room.ColumnInfo
import androidx.room.PrimaryKey

@Entity(tableName = "alarms")
data class AlarmEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val hour: Int,
    val minute: Int,
    val enabled: Boolean = true,
    /** ISO weekday numbers, Monday=1 through Sunday=7, comma-separated. Empty means one-time. */
    val repeatDays: String = "",
    val title: String = "",
    val note: String = "",
    val color: Long = 0xFFFF7A00,
    val soundUri: String? = null,
    val vibration: Boolean = true,
    val mathEnabled: Boolean = false,
    /** MATH, VOCAB, or MIXED challenge used to dismiss the alarm. */
    @ColumnInfo(defaultValue = "'MATH'") val challengeType: String = "MATH",
    val mathDifficulty: String = "EASY",
    val mathQuestionCount: Int = 2,
    val snoozeMinutes: Int = 5,
    val nextTriggerAt: Long? = null,
    /** Optional custom questions, one per line as question|integer-answer. */
    @ColumnInfo(defaultValue = "''") val customMathQuestions: String = "",
    /** Optional one-time date stored as ISO Gregorian date, regardless of input calendar. */
    val specificDate: String? = null,
    /** GREGORIAN or JALALI: calendar used to enter/display specificDate. */
    @ColumnInfo(defaultValue = "'GREGORIAN'") val dateCalendar: String = "GREGORIAN",
    @ColumnInfo(defaultValue = "100") val soundVolume: Int = 100
)

@Entity(tableName = "alarm_events")
data class AlarmEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val alarmId: Long,
    val eventType: String,
    val occurredAt: Long,
    val dismissedAt: Long? = null
)
