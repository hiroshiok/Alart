package com.alrart.app.alarm

import android.content.Context
import java.text.DateFormat
import java.util.Date

/** Small on-device trace so failed alarm delivery is visible instead of silently ignored. */
object AlarmDiagnostics {
    private const val PREFS = "alart_alarm_diagnostics"

    fun record(context: Context, event: String, detail: String = "") {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString("last_event", event)
            .putString("last_detail", detail.take(240))
            .putLong("last_event_at", System.currentTimeMillis())
            .apply()
    }

    fun read(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val event = prefs.getString("last_event", null) ?: return context.getString(com.alrart.app.R.string.diagnostics_no_events)
        val detail = prefs.getString("last_detail", "").orEmpty()
        val at = prefs.getLong("last_event_at", 0L)
        val time = if (at > 0L) DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(at)) else ""
        return listOf(event, time, detail).filter { it.isNotBlank() }.joinToString(" · ")
    }
}
