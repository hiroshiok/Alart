package com.alrart.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.alrart.app.widget.AlartWidget

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Clock/time-zone changes invalidate cached wall-clock timestamps. Recompute
                // the next occurrence from the alarm's local time and recurrence definition.
                val action = intent.action
                if (action == Intent.ACTION_TIME_CHANGED || action == Intent.ACTION_TIMEZONE_CHANGED) {
                    val dao = com.alrart.app.data.AlartDatabase.get(context).alarmDao()
                    dao.enabled().forEach { dao.setNextTrigger(it.id, null) }
                }
                AlarmScheduler(context).rescheduleAll()
                try { AlartWidget().updateAll(context) } catch (_: Exception) { }
            } finally { pending.finish() }
        }
    }
}
