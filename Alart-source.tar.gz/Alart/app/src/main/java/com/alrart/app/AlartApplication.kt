package com.alrart.app

import android.app.Application
import com.alrart.app.data.AlartDatabase
import com.alrart.app.alarm.AlarmScheduler

class AlartApplication : Application() {
    val database by lazy { AlartDatabase.get(this) }
    val scheduler by lazy { AlarmScheduler(this) }
}
