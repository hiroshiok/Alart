package com.alrart.app.ui

import android.os.Bundle
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.provider.Settings
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.alrart.app.R
import com.alrart.app.alarm.AlarmActionReceiver
import com.alrart.app.alarm.AlarmReceiver
import com.alrart.app.data.AlarmEntity
import com.alrart.app.data.AlartDatabase
import com.alrart.app.data.SettingsStore
import com.alrart.app.domain.MathAnswer
import com.alrart.app.ui.theme.AlartTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.random.Random

private data class MathChallenge(val prompt: String, val answer: Int)

private fun parseCustomChallenges(raw: String): List<MathChallenge> = raw.lineSequence().mapNotNull { line ->
    val separator = line.lastIndexOf('|')
    if (separator <= 0) null else {
        val prompt = line.substring(0, separator).trim()
        val answer = MathAnswer.normalizeDigits(line.substring(separator + 1)).toIntOrNull()
        if (prompt.isBlank() || answer == null) null else MathChallenge(prompt, answer)
    }
}.take(20).toList()

private fun makeChallenge(level: String): MathChallenge {
    val a = Random.nextInt(3, 13)
    val b = Random.nextInt(2, 13)
    return when (level) {
        "MEDIUM" -> if (Random.nextBoolean()) {
            MathChallenge("$a × $b = ?", a * b)
        } else {
            val divisor = Random.nextInt(2, 10)
            val quotient = Random.nextInt(2, 13)
            MathChallenge("${divisor * quotient} ÷ $divisor = ?", quotient)
        }
        "HARD" -> when (Random.nextInt(3)) {
            0 -> {
                val c = Random.nextInt(2, 10)
                MathChallenge("($a + $b) × $c = ?", (a + b) * c)
            }
            1 -> {
                val c = Random.nextInt(2, 20)
                MathChallenge("$a × $b − $c = ?", a * b - c)
            }
            else -> {
                val c = Random.nextInt(2, 20)
                MathChallenge("($a × $b) + $c = ?", a * b + c)
            }
        }
        else -> if (Random.nextBoolean()) MathChallenge("$a + $b = ?", a + b)
            else MathChallenge("${a + b} − $a = ?", b)
    }
}

class RingingActivity : AppCompatActivity() {
    private var mathLocked = true
    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getLongExtra(AlarmReceiver.EXTRA_ALARM_ID, -1L)
        if (id < 0L) { finish(); return }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!mathLocked) {
                    sendAction(AlarmActionReceiver.ACTION_STOP, id)
                    finish()
                }
            }
        })
        if (android.os.Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        setContent {
            var alarm by remember { mutableStateOf<AlarmEntity?>(null) }
            val settings = remember { SettingsStore(applicationContext) }
            val fontFamily by settings.fontFamily.collectAsState(initial = "sans")
            val themeMode by settings.themeMode.collectAsState(initial = "system")
            val dark = when (themeMode) { "dark" -> true; "light" -> false; else -> androidx.compose.foundation.isSystemInDarkTheme() }
            LaunchedEffect(id) {
                val loaded = withContext(Dispatchers.IO) { AlartDatabase.get(this@RingingActivity).alarmDao().get(id) }
                alarm = loaded
                mathLocked = loaded?.mathEnabled == true
                if (loaded == null) finish()
            }
            LaunchedEffect(alarm?.id) {
                alarm?.let { activeAlarm ->
                    // Do not trust startForegroundService() returning as proof that audio
                    // actually began. Wait for the playback service to confirm it.
                    kotlinx.coroutines.delay(1500)
                    val state = getSharedPreferences("alart_audio_state", MODE_PRIVATE)
                    if (state.getLong("playing_alarm_id", -1L) != activeAlarm.id) {
                        val startingId = state.getLong("starting_alarm_id", -1L)
                        val startedAt = state.getLong("starting_at", 0L)
                        if (startingId == activeAlarm.id && System.currentTimeMillis() - startedAt < 5000L) {
                            kotlinx.coroutines.delay(3500)
                        }
                        if (state.getLong("playing_alarm_id", -1L) != activeAlarm.id) startRinging(activeAlarm)
                    }
                }
            }
            AlartTheme(darkTheme = dark, fontChoice = fontFamily) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    RingingContent(
                        alarm = alarm,
                        onSnooze = { sendAction(AlarmActionReceiver.ACTION_SNOOZE, id); finish() },
                        onStop = { sendAction(AlarmActionReceiver.ACTION_STOP, id); finish() }
                    )
                }
            }
        }
    }

    private fun startRinging(alarm: AlarmEntity) {
        stopRinging()
        val candidates = listOfNotNull(
            alarm.soundUri?.let { runCatching { Uri.parse(it) }.getOrNull() },
            Settings.System.DEFAULT_ALARM_ALERT_URI,
            Settings.System.DEFAULT_NOTIFICATION_URI
        ).distinct()
        for (candidate in candidates) {
            val player = runCatching { RingtoneManager.getRingtone(this, candidate) }.getOrNull() ?: continue
            val started = runCatching {
                player.audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                if (android.os.Build.VERSION.SDK_INT >= 28) player.isLooping = true
                player.play()
                true
            }.getOrDefault(false)
            if (started) { ringtone = player; break } else runCatching { player.stop() }
        }
        if (alarm.vibration) {
            vibrator = getSystemService(Vibrator::class.java)
            val pattern = longArrayOf(0, 650, 350)
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        }
    }

    private fun stopRinging() {
        ringtone?.stop()
        ringtone = null
        vibrator?.cancel()
    }

    override fun onDestroy() {
        stopRinging()
        super.onDestroy()
    }

    private fun sendAction(action: String, id: Long) {
        stopRinging()
        sendBroadcast(android.content.Intent(this, AlarmActionReceiver::class.java).setAction(action).putExtra(AlarmReceiver.EXTRA_ALARM_ID, id))
    }
}

@Composable
private fun RingingContent(alarm: AlarmEntity?, onSnooze: () -> Unit, onStop: () -> Unit) {
    val challenges = remember(alarm?.id) {
        val count = if (alarm?.mathEnabled == true) alarm.mathQuestionCount.coerceIn(1, 5) else 0
        val custom = alarm?.customMathQuestions?.let(::parseCustomChallenges).orEmpty()
        if (custom.isNotEmpty()) List(count) { custom[it % custom.size] }
        else List(count) { makeChallenge(alarm?.mathDifficulty ?: "EASY") }
    }
    var index by remember(alarm?.id) { mutableIntStateOf(0) }
    var answer by remember { mutableStateOf("") }
    var feedback by remember { mutableStateOf("") }
    val wrongAnswerText = stringResource(R.string.math_wrong)
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineMedium)
        Text(java.time.LocalTime.now().toString().take(5), style = MaterialTheme.typography.displayLarge)
        Text(alarm?.title.orEmpty(), style = MaterialTheme.typography.titleLarge)
        if (!alarm?.note.isNullOrBlank()) Text(alarm?.note.orEmpty(), style = MaterialTheme.typography.bodyMedium)
        if (challenges.isNotEmpty()) {
            Text(stringResource(R.string.math_prompt), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 24.dp))
            Text(stringResource(R.string.math_progress, index + 1, challenges.size), style = MaterialTheme.typography.labelLarge)
            Text(challenges.getOrNull(index)?.prompt.orEmpty(), style = MaterialTheme.typography.displaySmall, modifier = Modifier.padding(12.dp))
            OutlinedTextField(value = answer, onValueChange = { answer = it; feedback = "" }, label = { Text(stringResource(R.string.math_answer_hint)) }, singleLine = true)
            if (feedback.isNotBlank()) Text(feedback, color = MaterialTheme.colorScheme.error)
            Button(onClick = {
                val current = challenges.getOrNull(index) ?: return@Button
                if (MathAnswer.isCorrect(answer, current.answer)) {
                    if (index + 1 == challenges.size) onStop() else { index++; answer = ""; feedback = "" }
                } else feedback = wrongAnswerText
            }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) { Text(stringResource(R.string.stop)) }
        } else {
            Button(onClick = onStop, modifier = Modifier.fillMaxWidth().padding(top = 18.dp)) { Text(stringResource(R.string.stop)) }
        }
        if (alarm?.mathEnabled != true) {
            Button(onClick = onSnooze, modifier = Modifier.fillMaxWidth()) { Text("${stringResource(R.string.snooze)} · ${alarm?.snoozeMinutes ?: 5} ${stringResource(R.string.minutes)}") }
        }
    }
}
