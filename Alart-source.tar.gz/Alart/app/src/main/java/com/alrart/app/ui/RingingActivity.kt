package com.alrart.app.ui

import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alrart.app.R
import com.alrart.app.alarm.AlarmActionReceiver
import com.alrart.app.alarm.AlarmReceiver
import com.alrart.app.data.AlarmEntity
import com.alrart.app.data.AlartDatabase
import com.alrart.app.data.SettingsStore
import com.alrart.app.domain.MathAnswer
import com.alrart.app.ui.theme.AlartTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.random.Random

private data class MathChallenge(val prompt: String, val answer: Int)
private data class VocabularyChallenge(val word: String, val answer: String, val options: List<String>)
private sealed interface DismissChallenge {
    data class Math(val value: MathChallenge) : DismissChallenge
    data class Vocabulary(val value: VocabularyChallenge) : DismissChallenge
}

private val vocabulary = listOf(
    "apple" to "سیب", "book" to "کتاب", "bright" to "روشن", "chair" to "صندلی",
    "choose" to "انتخاب کردن", "clean" to "تمیز", "clock" to "ساعت", "dream" to "رویا",
    "early" to "زود", "family" to "خانواده", "friend" to "دوست", "garden" to "باغ",
    "happy" to "خوشحال", "learn" to "یاد گرفتن", "light" to "نور", "morning" to "صبح",
    "quiet" to "آرام", "remember" to "به خاطر سپردن", "school" to "مدرسه", "water" to "آب",
    "window" to "پنجره", "write" to "نوشتن", "travel" to "سفر کردن", "strong" to "قوی"
)

private fun parseCustomChallenges(raw: String): List<MathChallenge> = raw.lineSequence().mapNotNull { line ->
    val separator = line.lastIndexOf('|')
    if (separator <= 0) null else {
        val prompt = line.substring(0, separator).trim()
        val answer = MathAnswer.normalizeDigits(line.substring(separator + 1)).toIntOrNull()
        if (prompt.isBlank() || answer == null) null else MathChallenge(prompt, answer)
    }
}.take(20).toList()

private fun makeChallenge(level: String): MathChallenge {
    val a = Random.nextInt(3, 13)
    val b = Random.nextInt(2, 13)
    return when (level) {
        "MEDIUM" -> if (Random.nextBoolean()) MathChallenge("$a × $b = ?", a * b) else {
            val divisor = Random.nextInt(2, 10)
            val quotient = Random.nextInt(2, 13)
            MathChallenge("${divisor * quotient} ÷ $divisor = ?", quotient)
        }
        "HARD" -> when (Random.nextInt(3)) {
            0 -> { val c = Random.nextInt(2, 10); MathChallenge("($a + $b) × $c = ?", (a + b) * c) }
            1 -> { val c = Random.nextInt(2, 20); MathChallenge("$a × $b − $c = ?", a * b - c) }
            else -> { val c = Random.nextInt(2, 20); MathChallenge("($a × $b) + $c = ?", a * b + c) }
        }
        else -> if (Random.nextBoolean()) MathChallenge("$a + $b = ?", a + b) else MathChallenge("${a + b} − $a = ?", b)
    }
}

private fun makeVocabularyChallenge(): VocabularyChallenge {
    val selected = vocabulary.random()
    val distractors = vocabulary.filterNot { it == selected }.shuffled().take(3).map { it.second }
    return VocabularyChallenge(selected.first, selected.second, (distractors + selected.second).shuffled())
}

private fun makeDismissChallenges(alarm: AlarmEntity?): List<DismissChallenge> {
    if (alarm?.mathEnabled != true) return emptyList()
    val count = alarm.mathQuestionCount.coerceIn(1, 5)
    val mode = alarm.challengeType.uppercase()
    val custom = alarm.customMathQuestions.let(::parseCustomChallenges)
    val actualCount = if (mode == "MIXED" && count == 1) 2 else count
    var mathIndex = 0
    return List(actualCount) { index ->
        val useVocabulary = mode == "VOCAB" || (mode == "MIXED" && index % 2 == 1)
        if (useVocabulary) DismissChallenge.Vocabulary(makeVocabularyChallenge())
        else {
            val value = custom.getOrNull(mathIndex % custom.size.coerceAtLeast(1)) ?: makeChallenge(alarm.mathDifficulty)
            mathIndex++
            DismissChallenge.Math(value)
        }
    }
}

class RingingActivity : AppCompatActivity() {
    private var challengeLocked = true
    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getLongExtra(AlarmReceiver.EXTRA_ALARM_ID, -1L)
        if (id < 0L) { finish(); return }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!challengeLocked) {
                    sendAction(AlarmActionReceiver.ACTION_STOP, id)
                    finish()
                }
            }
        })
        if (android.os.Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        setContent {
            var alarm by remember { mutableStateOf<AlarmEntity?>(null) }
            val settings = remember { SettingsStore(applicationContext) }
            val fontFamily by settings.fontFamily.collectAsState(initial = "sans")
            val themeMode by settings.themeMode.collectAsState(initial = "system")
            val dark = when (themeMode) { "dark" -> true; "light" -> false; else -> androidx.compose.foundation.isSystemInDarkTheme() }
            LaunchedEffect(id) {
                val loaded = withContext(Dispatchers.IO) { AlartDatabase.get(this@RingingActivity).alarmDao().get(id) }
                alarm = loaded
                challengeLocked = loaded?.mathEnabled == true
                if (loaded == null) finish()
            }
            LaunchedEffect(alarm?.id) {
                alarm?.let { activeAlarm ->
                    // The foreground service confirms playback asynchronously; only fall back if it did not start.
                    kotlinx.coroutines.delay(1500)
                    val state = getSharedPreferences("alart_audio_state", MODE_PRIVATE)
                    if (state.getLong("playing_alarm_id", -1L) != activeAlarm.id) {
                        val startingId = state.getLong("starting_alarm_id", -1L)
                        val startedAt = state.getLong("starting_at", 0L)
                        if (startingId == activeAlarm.id && System.currentTimeMillis() - startedAt < 5000L) kotlinx.coroutines.delay(3500)
                        if (state.getLong("playing_alarm_id", -1L) != activeAlarm.id) startRinging(activeAlarm)
                    }
                }
            }
            AlartTheme(darkTheme = dark, fontChoice = fontFamily) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    RingingContent(
                        alarm = alarm,
                        onSnooze = { sendAction(AlarmActionReceiver.ACTION_SNOOZE, id); finish() },
                        onStop = { sendAction(AlarmActionReceiver.ACTION_STOP, id); finish() }
                    )
                }
            }
        }
    }

    private fun startRinging(alarm: AlarmEntity) {
        stopRinging()
        val candidates = listOfNotNull(
            alarm.soundUri?.let { runCatching { Uri.parse(it) }.getOrNull() },
            Settings.System.DEFAULT_ALARM_ALERT_URI,
            Settings.System.DEFAULT_NOTIFICATION_URI
        ).distinct()
        for (candidate in candidates) {
            val player = runCatching { RingtoneManager.getRingtone(this, candidate) }.getOrNull() ?: continue
            val started = runCatching {
                player.audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                if (android.os.Build.VERSION.SDK_INT >= 28) player.isLooping = true
                player.play()
                true
            }.getOrDefault(false)
            if (started) { ringtone = player; break } else runCatching { player.stop() }
        }
        if (alarm.vibration) {
            vibrator = getSystemService(Vibrator::class.java)
            val pattern = longArrayOf(0, 650, 350)
            if (android.os.Build.VERSION.SDK_INT >= 26) vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        }
    }

    private fun stopRinging() {
        ringtone?.stop()
        ringtone = null
        vibrator?.cancel()
    }

    override fun onDestroy() {
        stopRinging()
        super.onDestroy()
    }

    private fun sendAction(action: String, id: Long) {
        stopRinging()
        sendBroadcast(android.content.Intent(this, AlarmActionReceiver::class.java).setAction(action).putExtra(AlarmReceiver.EXTRA_ALARM_ID, id))
    }
}

@Composable
private fun RingingContent(alarm: AlarmEntity?, onSnooze: () -> Unit, onStop: () -> Unit) {
    val challenges = remember(alarm?.id, alarm?.challengeType, alarm?.mathQuestionCount, alarm?.customMathQuestions) { makeDismissChallenges(alarm) }
    var index by remember(alarm?.id) { mutableIntStateOf(0) }
    var answer by remember { mutableStateOf("") }
    var feedback by remember { mutableStateOf("") }
    val wrongAnswerText = stringResource(R.string.math_wrong)
    val vocabWrongText = stringResource(R.string.vocab_wrong)
    val challenge = challenges.getOrNull(index)

    fun advance() {
        if (index + 1 >= challenges.size) onStop()
        else { index++; answer = ""; feedback = "" }
    }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.primaryContainer) {
            Text("ALART  •  ${stringResource(R.string.app_name)}", modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp), color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }
        Spacer(Modifier.height(14.dp))
        Text(java.time.LocalTime.now().toString().take(5), style = MaterialTheme.typography.displayLarge, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Light)
        Text(alarm?.title?.ifBlank { null } ?: stringResource(R.string.no_alarm_label), style = MaterialTheme.typography.titleLarge)
        if (!alarm?.note.isNullOrBlank()) Text(alarm?.note.orEmpty(), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))

        if (challenge != null) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(30.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(stringResource(R.string.challenge_progress, index + 1, challenges.size), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    when (challenge) {
                        is DismissChallenge.Math -> {
                            Text(stringResource(R.string.challenge_prompt), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(challenge.value.prompt, style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.onSurface)
                            OutlinedTextField(
                                value = answer,
                                onValueChange = { answer = it; feedback = "" },
                                label = { Text(stringResource(R.string.math_answer_hint)) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Button(onClick = {
                                if (MathAnswer.isCorrect(answer, challenge.value.answer)) advance() else feedback = wrongAnswerText
                            }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.continue_challenge)) }
                        }
                        is DismissChallenge.Vocabulary -> {
                            Text(stringResource(R.string.vocab_prompt), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(challenge.value.word, style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            challenge.value.options.forEach { option ->
                                OutlinedButton(
                                    onClick = { if (option == challenge.value.answer) advance() else feedback = vocabWrongText },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text(option, style = MaterialTheme.typography.titleMedium) }
                            }
                        }
                    }
                    if (feedback.isNotBlank()) Text(feedback, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else {
            Button(onClick = onStop, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.stop)) }
        }

        if (alarm?.mathEnabled != true) {
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = onSnooze, modifier = Modifier.fillMaxWidth()) {
                Text("${stringResource(R.string.snooze)} · ${alarm?.snoozeMinutes ?: 5} ${stringResource(R.string.minutes)}")
            }
        }
    }
}
