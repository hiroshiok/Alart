package com.alrart.app

import androidx.glance.appwidget.updateAll
import android.app.TimePickerDialog
import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.core.view.WindowCompat
import androidx.core.app.NotificationManagerCompat
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import com.alrart.app.alarm.AlarmScheduler
import com.alrart.app.data.AlarmEntity
import com.alrart.app.data.SettingsStore
import com.alrart.app.data.AlarmEventEntity
import com.alrart.app.domain.Statistics
import com.alrart.app.domain.AlarmTime
import com.alrart.app.domain.JalaliDate
import com.alrart.app.ui.theme.AlartTheme
import com.alrart.app.widget.AlartWidget
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        notificationAccess.value = granted || NotificationManagerCompat.from(this).areNotificationsEnabled()
    }
    private val exactAlarmAccess = mutableStateOf(false)
    private val notificationAccess = mutableStateOf(false)

    private fun refreshAccessState() {
        exactAlarmAccess.value = AlarmScheduler(this).canScheduleExact()
        notificationAccess.value = NotificationManagerCompat.from(this).areNotificationsEnabled()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        refreshAccessState()
        setContent {
            val settings = remember { SettingsStore(applicationContext) }
            val themeMode by settings.themeMode.collectAsState(initial = "system")
            val fontFamily by settings.fontFamily.collectAsState(initial = "sans")
            val defaultVibration by settings.defaultVibration.collectAsState(initial = true)
            val defaultSnooze by settings.defaultSnoozeMinutes.collectAsState(initial = 5)
            val defaultSound by settings.defaultSoundUri.collectAsState(initial = null)
            val selectedDark = when (themeMode) { "dark" -> true; "light" -> false; else -> null }
            val resolvedDark = selectedDark ?: androidx.compose.foundation.isSystemInDarkTheme()
            SideEffect {
                WindowCompat.getInsetsController(window, window.decorView).apply {
                    isAppearanceLightStatusBars = !resolvedDark
                    isAppearanceLightNavigationBars = !resolvedDark
                }
            }
            AlartTheme(darkTheme = resolvedDark, fontChoice = fontFamily) {
                AlartApp(dark = selectedDark, fontFamily = fontFamily, defaultVibration = defaultVibration, defaultSnooze = defaultSnooze, defaultSound = defaultSound,
                    exactAllowed = exactAlarmAccess.value, notificationsAllowed = notificationAccess.value,
                    onFont = { value -> lifecycleScope.launch { settings.setFontFamily(value) } },
                    onDefaultVibration = { value -> lifecycleScope.launch { settings.setDefaultVibration(value) } },
                    onDefaultSnooze = { value -> lifecycleScope.launch { settings.setDefaultSnoozeMinutes(value) } },
                    onDefaultSound = { value -> lifecycleScope.launch { settings.setDefaultSoundUri(value) } }, onRequestNotifications = {
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) notificationPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                }, onPermission = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) runCatching {
                        startActivity(Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                    }
                }, onFullScreenPermission = {
                    if (Build.VERSION.SDK_INT >= 34) runCatching {
                        startActivity(Intent(android.provider.Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
                    }
                }, onTestAlarm = { scheduleTestAlarm() }, onTestSoundNow = { playTestSoundNow() }, onDark = { value ->
                    lifecycleScope.launch { settings.setThemeMode(when (value) { true -> "dark"; false -> "light"; null -> "system" }) }
                })
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshAccessState()
        val scheduler = AlarmScheduler(this)
        lifecycleScope.launch { runCatching { scheduler.rescheduleAll() } }
    }

    private fun playTestSoundNow() {
        val playback = Intent(this, com.alrart.app.alarm.AlarmSoundService::class.java).apply {
            action = com.alrart.app.alarm.AlarmSoundService.ACTION_START
            putExtra(com.alrart.app.alarm.AlarmReceiver.EXTRA_ALARM_ID, com.alrart.app.alarm.AlarmTestReceiver.TEST_ALARM_ID)
            putExtra(com.alrart.app.alarm.AlarmReceiver.EXTRA_ALARM_TITLE, getString(R.string.test_alarm))
            putExtra(com.alrart.app.alarm.AlarmReceiver.EXTRA_VIBRATION, true)
            putExtra(com.alrart.app.alarm.AlarmReceiver.EXTRA_SOUND_VOLUME, 100)
            putExtra(com.alrart.app.alarm.AlarmSoundService.EXTRA_TEST_MODE, true)
        }
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(playback) else startService(playback)
            com.alrart.app.alarm.AlarmDiagnostics.record(this, "TEST_SOUND_REQUESTED", "Foreground service started directly from Settings")
        }.onFailure { error ->
            com.alrart.app.alarm.AlarmDiagnostics.record(this, "TEST_SOUND_START_FAILED", "${error.javaClass.simpleName}: ${error.message}")
        }
    }

    private fun scheduleTestAlarm() {
        val manager = getSystemService(android.app.AlarmManager::class.java)
        val exactAllowed = AlarmScheduler(this).canScheduleExact()
        val triggerAt = System.currentTimeMillis() + 10_000L
        val testIntent = Intent(this, com.alrart.app.alarm.AlarmTestReceiver::class.java).apply {
            action = "com.alrart.app.alarm.TEST_TRIGGER"
            data = Uri.parse("alart://test-alarm/$triggerAt")
        }
        val operation = PendingIntent.getBroadcast(
            this, com.alrart.app.alarm.AlarmTestReceiver.REQUEST_CODE, testIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val show = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        runCatching {
            if (exactAllowed) {
                manager.setAlarmClock(android.app.AlarmManager.AlarmClockInfo(triggerAt, show), operation)
            } else {
                manager.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, triggerAt, operation)
            }
            com.alrart.app.alarm.AlarmDiagnostics.record(this, if (exactAllowed) "TEST_ALARM_SCHEDULED_EXACT" else "TEST_ALARM_SCHEDULED_APPROXIMATE", "Expected in about 10 seconds; trigger=$triggerAt")
        }.onFailure { error ->
            com.alrart.app.alarm.AlarmDiagnostics.record(this, "TEST_SCHEDULE_FAILED", "${error.javaClass.simpleName}: ${error.message}")
        }
    }
}

private enum class Destination { ALARMS, CALENDAR, ANALYTICS, SETTINGS }

@Composable
private fun AlartApp(
    dark: Boolean?, fontFamily: String, defaultVibration: Boolean, defaultSnooze: Int, defaultSound: String?,
    exactAllowed: Boolean, notificationsAllowed: Boolean,
    onFont: (String) -> Unit, onDefaultVibration: (Boolean) -> Unit, onDefaultSnooze: (Int) -> Unit,
    onDefaultSound: (String?) -> Unit, onRequestNotifications: () -> Unit, onPermission: () -> Unit,
    onFullScreenPermission: () -> Unit, onTestAlarm: () -> Unit, onTestSoundNow: () -> Unit, onDark: (Boolean?) -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as AlartApplication
    val dao = remember { app.database.alarmDao() }
    val alarms by dao.observeAll().collectAsState(initial = emptyList())
    val events by dao.observeEvents().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var destination by remember { mutableStateOf(Destination.ALARMS) }
    var editor by remember { mutableStateOf<AlarmEntity?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val scheduler = remember { AlarmScheduler(context) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(message) { message?.let { snackbar.showSnackbar(it); message = null } }

    Box(Modifier.fillMaxSize()) {
        AmbientBackdrop()
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                GlassBottomBar(destination = destination, onSelect = { destination = it })
            }
        ) { padding ->
            AnimatedContent(
                targetState = destination,
                modifier = Modifier.fillMaxSize().padding(padding),
                label = "main_navigation"
            ) { page ->
                when (page) {
                    Destination.ALARMS -> AlarmHome(
                        alarms = alarms,
                        exactAllowed = exactAllowed,
                        onGrantExact = onPermission,
                        onToggle = { alarm, enabled ->
                            scope.launch {
                                dao.setEnabled(alarm.id, enabled)
                                val updated = alarm.copy(enabled = enabled, nextTriggerAt = null)
                                val scheduledAt = scheduler.schedule(updated)
                                if (scheduledAt == null) {
                                    dao.setNextTrigger(alarm.id, null)
                                    message = context.getString(R.string.permission_needed)
                                    if (enabled && !scheduler.canScheduleExact()) onPermission()
                                } else {
                                    dao.setNextTrigger(alarm.id, scheduledAt.takeIf { it > 0L })
                                }
                                if (!enabled) NotificationManagerCompat.from(context).cancel(alarm.id.toInt())
                                refreshAlartWidget(context)
                            }
                        },
                        onEdit = { editor = it; showEditor = true },
                        onDelete = { alarm ->
                            scope.launch {
                                scheduler.cancel(alarm.id)
                                NotificationManagerCompat.from(context).cancel(alarm.id.toInt())
                                dao.delete(alarm.id)
                                refreshAlartWidget(context)
                            }
                        },
                        onAdd = { editor = null; showEditor = true }
                    )
                    Destination.CALENDAR -> CalendarPage(alarms)
                    Destination.ANALYTICS -> AnalyticsPage(events)
                    Destination.SETTINGS -> SettingsPage(
                        dark = dark,
                        onDark = onDark,
                        fontFamily = fontFamily,
                        onFont = onFont,
                        defaultVibration = defaultVibration,
                        onDefaultVibration = onDefaultVibration,
                        defaultSnooze = defaultSnooze,
                        onDefaultSnooze = onDefaultSnooze,
                        defaultSound = defaultSound,
                        onDefaultSound = onDefaultSound,
                        exactAllowed = exactAllowed,
                        notificationsAllowed = notificationsAllowed,
                        onRequestNotifications = onRequestNotifications,
                        onPermission = onPermission,
                        onFullScreenPermission = onFullScreenPermission,
                        onTestAlarm = onTestAlarm,
                        onTestSoundNow = onTestSoundNow,
                        onLanguage = { tag -> AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag)) }
                    )
                }
            }
        }
    }

    if (showEditor) {
        AlarmEditorDialog(initial = editor, defaultVibration = defaultVibration, defaultSnooze = defaultSnooze, defaultSound = defaultSound, onDismiss = { showEditor = false }, onSave = { alarm ->
            scope.launch {
                val id = dao.upsert(alarm)
                val saved = alarm.copy(id = if (alarm.id == 0L) id else alarm.id)
                val scheduledAt = scheduler.schedule(saved)
                if (scheduledAt == null) {
                    // Keep the alarm enabled in storage; silently disabling it made the
                    // app appear to save alarms that could never ring.
                    dao.setEnabled(saved.id, saved.enabled)
                    dao.setNextTrigger(saved.id, null)
                    message = context.getString(R.string.permission_needed)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !scheduler.canScheduleExact()) onPermission()
                } else {
                    dao.setNextTrigger(saved.id, scheduledAt.takeIf { it > 0L })
                    if (alarm.id == 0L) dao.addEvent(AlarmEventEntity(alarmId = saved.id, eventType = "SET", occurredAt = System.currentTimeMillis()))
                    message = context.getString(R.string.alarm_saved)
                }
                refreshAlartWidget(context)
                showEditor = false
            }
        })
    }
}

private suspend fun refreshAlartWidget(context: android.content.Context) {
    try { AlartWidget().updateAll(context) } catch (_: Exception) { }
}

@Composable
private fun AmbientBackdrop() {
    val colors = MaterialTheme.colorScheme
    Box(Modifier.fillMaxSize().background(
        Brush.linearGradient(listOf(colors.background, colors.surfaceVariant.copy(alpha = 0.70f), colors.background))
    )) {
        Canvas(Modifier.fillMaxSize()) {
            val firstCenter = Offset(size.width * 0.92f, size.height * 0.06f)
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(colors.primary.copy(alpha = 0.16f), Color.Transparent),
                    center = firstCenter,
                    radius = size.width * 0.78f
                ),
                radius = size.width * 0.78f,
                center = firstCenter
            )
            val secondCenter = Offset(size.width * 0.04f, size.height * 0.72f)
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(colors.tertiary.copy(alpha = 0.11f), Color.Transparent),
                    center = secondCenter,
                    radius = size.width * 0.72f
                ),
                radius = size.width * 0.72f,
                center = secondCenter
            )
        }
    }
}

@Composable
private fun GlassBottomBar(destination: Destination, onSelect: (Destination) -> Unit) {
    val items = listOf(
        Triple(Destination.ALARMS, Icons.Rounded.Alarm, R.string.alarms),
        Triple(Destination.CALENDAR, Icons.Rounded.CalendarMonth, R.string.calendar),
        Triple(Destination.ANALYTICS, Icons.Rounded.Insights, R.string.analytics),
        Triple(Destination.SETTINGS, Icons.Rounded.Settings, R.string.settings)
    )
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp)
            .clip(RoundedCornerShape(30.dp))
            .background(Brush.verticalGradient(listOf(cs.surface.copy(alpha = 0.94f), cs.surfaceVariant.copy(alpha = 0.84f))))
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.76f), cs.outlineVariant.copy(alpha = 0.56f))), RoundedCornerShape(30.dp))
            .padding(6.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
            items.forEach { (target, image, label) ->
                val selected = destination == target
                Column(
                    modifier = Modifier.weight(1f).clip(RoundedCornerShape(24.dp))
                        .background(if (selected) Brush.linearGradient(listOf(cs.primary.copy(alpha = 0.18f), cs.tertiary.copy(alpha = 0.12f))) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)))
                        .clickable { onSelect(target) }.padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Icon(image, contentDescription = stringResource(label), tint = if (selected) cs.primary else cs.onSurfaceVariant, modifier = Modifier.size(22.dp))
                    Text(stringResource(label), style = MaterialTheme.typography.labelSmall, color = if (selected) cs.primary else cs.onSurfaceVariant, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun AlarmHome(
    alarms: List<AlarmEntity>,
    exactAllowed: Boolean,
    onGrantExact: () -> Unit,
    onToggle: (AlarmEntity, Boolean) -> Unit,
    onEdit: (AlarmEntity) -> Unit,
    onDelete: (AlarmEntity) -> Unit,
    onAdd: () -> Unit
) {
    var now by remember { mutableStateOf(java.time.LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(20_000L)
            now = java.time.LocalDateTime.now()
        }
    }
    val upcoming = remember(alarms, now) {
        alarms.filter { it.enabled }
            .mapNotNull { alarm -> AlarmTime.nextOccurrence(alarm, now)?.let { alarm to it } }
            .minByOrNull { it.second }
    }
    val dayNames = listOf(
        stringResource(R.string.monday), stringResource(R.string.tuesday), stringResource(R.string.wednesday),
        stringResource(R.string.thursday), stringResource(R.string.friday), stringResource(R.string.saturday), stringResource(R.string.sunday)
    )
    val activeCount = alarms.count { it.enabled }
    val timeRemaining = upcoming?.second?.let { trigger ->
        val minutes = ((trigger - now.atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()).coerceAtLeast(0L) / 60_000L)
        val hours = minutes / 60L
        val remainder = minutes % 60L
        if (hours > 0) "%d:%02d".format(hours, remainder) else "%d %s".format(remainder, stringResource(R.string.minutes))
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, top = 22.dp, end = 20.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("ALART  /  ALARM STUDIO", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                    Text(stringResource(R.string.app_name), style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.SemiBold)
                }
                Surface(
                    onClick = onAdd,
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shadowElevation = 8.dp
                ) {
                    Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Add, contentDescription = stringResource(R.string.add_alarm), modifier = Modifier.size(28.dp))
                    }
                }
            }
        }

        if (!exactAllowed) {
            item {
                Surface(
                    onClick = onGrantExact,
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.92f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.22f))
                ) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Alarm, contentDescription = null, tint = MaterialTheme.colorScheme.onErrorContainer)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(stringResource(R.string.alarm_access_needed), color = MaterialTheme.colorScheme.onErrorContainer, fontWeight = FontWeight.Bold)
                            Text(stringResource(R.string.exact_access_explanation), color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall)
                        }
                        Text("›", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
            }
        }

        item {
            val cs = MaterialTheme.colorScheme
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(36.dp))
                    .background(Brush.linearGradient(listOf(cs.surface.copy(alpha = 0.92f), cs.primaryContainer.copy(alpha = 0.70f), cs.surfaceVariant.copy(alpha = 0.78f))))
                    .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.78f), cs.outlineVariant.copy(alpha = 0.55f))), RoundedCornerShape(36.dp))
                    .padding(24.dp)
            ) {
                Canvas(Modifier.matchParentSize()) {
                    drawCircle(Brush.radialGradient(listOf(cs.primary.copy(alpha = 0.17f), Color.Transparent), center = Offset(size.width * 0.92f, size.height * 0.04f), radius = size.width * 0.58f), radius = size.width * 0.58f, center = Offset(size.width * 0.92f, size.height * 0.04f))
                    drawCircle(Brush.radialGradient(listOf(cs.tertiary.copy(alpha = 0.12f), Color.Transparent), center = Offset(size.width * 0.08f, size.height * 0.96f), radius = size.width * 0.55f), radius = size.width * 0.55f, center = Offset(size.width * 0.08f, size.height * 0.96f))
                }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.next_alarm).uppercase(), style = MaterialTheme.typography.labelSmall, color = cs.primary, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                        Spacer(Modifier.weight(1f))
                        Text(stringResource(R.string.active_count, activeCount), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                    }
                    Text(
                        upcoming?.first?.let { "%02d:%02d".format(it.hour, it.minute) } ?: "--:--",
                        style = MaterialTheme.typography.displayLarge,
                        color = cs.onSurface,
                        fontWeight = FontWeight.Light,
                        letterSpacing = (-2.5).sp
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(upcoming?.first?.title?.ifBlank { null } ?: stringResource(R.string.no_upcoming_alarm_title), color = cs.onSurface, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(timeRemaining?.let { stringResource(R.string.time_left, it) } ?: stringResource(R.string.no_upcoming_alarm_hint), color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                        }
                        if (upcoming == null) {
                            GlassTextButton(stringResource(R.string.add_first_alarm)) { onAdd() }
                        }
                    }
                }
            }
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.upcoming_alarms), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Spacer(Modifier.weight(1f))
                Text(stringResource(R.string.active_count, activeCount), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        if (alarms.isEmpty()) {
            item {
                Surface(
                    onClick = onAdd,
                    shape = RoundedCornerShape(28.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f))
                ) {
                    Column(Modifier.fillMaxWidth().padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Rounded.Alarm, contentDescription = null, modifier = Modifier.size(42.dp), tint = MaterialTheme.colorScheme.primary)
                        Text(stringResource(R.string.no_upcoming_alarm_title), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text(stringResource(R.string.no_upcoming_alarm_hint), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                        Button(onClick = onAdd) { Text(stringResource(R.string.add_first_alarm)) }
                    }
                }
            }
        } else {
            items(alarms, key = { it.id }) { alarm ->
                val scheduleLabel = when {
                    alarm.specificDate != null -> runCatching {
                        val date = java.time.LocalDate.parse(alarm.specificDate)
                        if (alarm.dateCalendar == "JALALI") JalaliDate.fromGregorian(date).let { "%04d/%02d/%02d".format(it.year, it.month, it.day) }
                        else date.toString()
                    }.getOrDefault(alarm.specificDate)
                    alarm.repeatDays.isNotBlank() -> alarm.repeatDays.split(',').mapNotNull { it.toIntOrNull()?.minus(1) }.mapNotNull { weekdayIndex -> dayNames.getOrNull(weekdayIndex) }.joinToString(" · ")
                    else -> stringResource(R.string.once)
                }
                Column(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                            .background(if (alarm.enabled) MaterialTheme.colorScheme.surface.copy(alpha = 0.34f) else Color.Transparent)
                            .clickable { onEdit(alarm) }
                            .padding(horizontal = 4.dp, vertical = 13.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.width(4.dp).height(52.dp).clip(CircleShape).background(Color(alarm.color)))
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("%02d:%02d".format(alarm.hour, alarm.minute), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium, letterSpacing = (-0.6).sp)
                            Text(alarm.title.ifBlank { stringResource(R.string.no_alarm_label) }, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                            Text(scheduleLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, maxLines = 1)
                        }
                        Switch(checked = alarm.enabled, onCheckedChange = { onToggle(alarm, it) })
                        IconButton(onClick = { onDelete(alarm) }) {
                            Icon(Icons.Rounded.Delete, contentDescription = stringResource(R.string.delete), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.42f), thickness = 0.7.dp)
                }
            }
        }
    }
}

@Composable
private fun AlarmEditorDialog(initial: AlarmEntity?, defaultVibration: Boolean, defaultSnooze: Int, defaultSound: String?, onDismiss: () -> Unit, onSave: (AlarmEntity) -> Unit) {
    val context = LocalContext.current
    var hour by remember { mutableIntStateOf(initial?.hour ?: 7) }
    var minute by remember { mutableIntStateOf(initial?.minute ?: 0) }
    var title by remember { mutableStateOf(initial?.title.orEmpty()) }
    var note by remember { mutableStateOf(initial?.note.orEmpty()) }
    var days by remember { mutableStateOf(initial?.repeatDays?.split(',')?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()) }
    var vibration by remember(initial?.id) { mutableStateOf(initial?.vibration ?: defaultVibration) }
    var math by remember { mutableStateOf(initial?.mathEnabled ?: false) }
    var difficulty by remember { mutableStateOf(initial?.mathDifficulty ?: "EASY") }
    var questionCount by remember { mutableIntStateOf(initial?.mathQuestionCount ?: 2) }
    var customQuestions by remember { mutableStateOf(initial?.customMathQuestions.orEmpty()) }
    var snooze by remember(initial?.id) { mutableIntStateOf(initial?.snoozeMinutes ?: defaultSnooze) }
    var color by remember { mutableLongStateOf(initial?.color ?: 0xFF6658D3) }
    var soundUri by remember(initial?.id) { mutableStateOf(if (initial == null) defaultSound else initial.soundUri) }
    var soundVolume by remember(initial?.id) { mutableIntStateOf(initial?.soundVolume ?: 100) }
    var dateCalendar by remember { mutableStateOf(initial?.dateCalendar ?: "GREGORIAN") }
    var dateInput by remember(initial?.id) {
        mutableStateOf(initial?.specificDate?.let { iso ->
            runCatching {
                val date = java.time.LocalDate.parse(iso)
                if (dateCalendar == "JALALI") com.alrart.app.domain.JalaliDate.fromGregorian(date).let { "%04d/%02d/%02d".format(it.year, it.month, it.day) }
                else iso
            }.getOrDefault(iso)
        } ?: "")
    }
    var dateError by remember { mutableStateOf(false) }
    var customQuestionError by remember { mutableStateOf(false) }
    fun switchDateCalendar(target: String) {
        if (target == dateCalendar) return
        if (dateInput.isNotBlank()) {
            val gregorian = runCatching {
                if (dateCalendar == "JALALI") com.alrart.app.domain.JalaliDate.parse(dateInput)?.toGregorian()
                else java.time.LocalDate.parse(dateInput.trim())
            }.getOrNull()
            if (gregorian != null) {
                dateInput = if (target == "JALALI") com.alrart.app.domain.JalaliDate.fromGregorian(gregorian).let { "%04d/%02d/%02d".format(it.year, it.month, it.day) } else gregorian.toString()
            }
        }
        dateCalendar = target
    }
    val soundPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val pickedUri = if (Build.VERSION.SDK_INT >= 33) {
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            }
            soundUri = pickedUri?.toString()
        }
    }
    val colors = listOf(0xFF6658D3, 0xFF168C78, 0xFFE07838, 0xFFD34F70, 0xFF3977C5, 0xFF8A8F98)
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val cs = MaterialTheme.colorScheme
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp).heightIn(max = 760.dp)
                .clip(RoundedCornerShape(34.dp))
                .background(Brush.verticalGradient(listOf(cs.surface.copy(alpha = 0.98f), cs.surfaceVariant.copy(alpha = 0.94f))))
                .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.78f), cs.outlineVariant.copy(alpha = 0.72f))), RoundedCornerShape(34.dp))
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("ALART  /  EDITOR", style = MaterialTheme.typography.labelSmall, color = cs.primary, letterSpacing = 1.3.sp, fontWeight = FontWeight.Bold)
                    Text(if (initial == null) stringResource(R.string.add_alarm) else stringResource(R.string.edit_alarm), style = MaterialTheme.typography.headlineSmall, color = cs.onSurface, fontWeight = FontWeight.SemiBold)
                }
                GlassTextButton("×") { onDismiss() }
            }
            Spacer(Modifier.height(16.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.primary.copy(alpha = 0.10f)).border(1.dp, cs.primary.copy(alpha = 0.16f), RoundedCornerShape(24.dp)).clickable {
                    TimePickerDialog(context, { _, h, m -> hour = h; minute = m }, hour, minute, true).show()
                }.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(stringResource(R.string.alarm_time), style = MaterialTheme.typography.labelSmall, color = cs.primary, fontWeight = FontWeight.Bold)
                        Text("%02d:%02d".format(hour, minute), style = MaterialTheme.typography.displayMedium, color = cs.onSurface, fontWeight = FontWeight.Light)
                    }
                    Text(stringResource(R.string.change), color = cs.primary, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                }
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text(stringResource(R.string.alarm_title)) }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp))
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text(stringResource(R.string.alarm_note)) }, modifier = Modifier.fillMaxWidth(), minLines = 2, shape = RoundedCornerShape(18.dp))

                SettingsLabel(stringResource(R.string.repeat))
                SettingsLabel(stringResource(R.string.specific_date))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassChoice(stringResource(R.string.gregorian), selected = dateCalendar == "GREGORIAN") { switchDateCalendar("GREGORIAN") }
                    GlassChoice(stringResource(R.string.solar_hijri), selected = dateCalendar == "JALALI") { switchDateCalendar("JALALI") }
                }
                OutlinedTextField(
                    value = dateInput,
                    onValueChange = { dateInput = it; dateError = false; if (it.isNotBlank()) days = emptySet() },
                    label = { Text(if (dateCalendar == "JALALI") stringResource(R.string.jalali_date_format) else stringResource(R.string.gregorian_date_format)) },
                    supportingText = { Text(stringResource(if (dateError) R.string.date_future_error else R.string.date_once_hint)) },
                    isError = dateError, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)
                )
                val dayLabels = listOf(R.string.monday, R.string.tuesday, R.string.wednesday, R.string.thursday, R.string.friday, R.string.saturday, R.string.sunday)
                val dayNames = dayLabels.map { stringResource(it) }
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    dayLabels.forEachIndexed { index, label ->
                        GlassChoice(stringResource(label).take(3), selected = index + 1 in days) {
                            val selected = index + 1 in days
                            days = if (selected) days - (index + 1) else days + (index + 1)
                            if (!selected) { dateInput = ""; dateError = false }
                        }
                    }
                }

                SettingsDivider()
                SettingsToggleRow(stringResource(R.string.vibration), stringResource(R.string.default_vibration), vibration) { vibration = it }
                SettingsLabel(stringResource(R.string.alarm_color))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    colors.forEach { swatch ->
                        Box(Modifier.size(34.dp).clip(CircleShape).background(Color(swatch)).border(if (color == swatch) 3.dp else 1.dp, if (color == swatch) cs.onSurface else Color.White.copy(alpha = 0.65f), CircleShape).clickable { color = swatch }, contentAlignment = Alignment.Center) {
                            if (color == swatch) Text("✓", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                SettingsDivider()
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        SettingsLabel(stringResource(R.string.alarm_sound))
                        Text(if (soundUri == null) stringResource(R.string.system_default) else stringResource(R.string.custom_sound_selected), color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                    GlassTextButton(stringResource(R.string.choose_sound)) {
                        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, context.getString(R.string.alarm_sound))
                            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, soundUri?.let { Uri.parse(it) })
                            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                        }
                        soundPicker.launch(intent)
                    }
                }
                Text("${stringResource(R.string.sound_volume)} · $soundVolume%", style = MaterialTheme.typography.labelLarge, color = cs.onSurface)
                Slider(value = soundVolume.toFloat(), onValueChange = { soundVolume = it.toInt() }, valueRange = 0f..100f, steps = 19)
                Text(stringResource(R.string.sound_volume_hint), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                Text("${stringResource(R.string.snooze_duration)} · $snooze ${stringResource(R.string.minutes)}", style = MaterialTheme.typography.labelLarge, color = cs.onSurface)
                Slider(value = snooze.toFloat(), onValueChange = { snooze = it.toInt() }, valueRange = 1f..30f, steps = 28)
                SettingsToggleRow(stringResource(R.string.math_dismissal), stringResource(R.string.math_difficulty), math) { math = it }
                if (math) {
                    SettingsLabel(stringResource(R.string.math_difficulty))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassChoice(stringResource(R.string.easy), difficulty == "EASY") { difficulty = "EASY" }
                        GlassChoice(stringResource(R.string.medium), difficulty == "MEDIUM") { difficulty = "MEDIUM" }
                        GlassChoice(stringResource(R.string.hard), difficulty == "HARD") { difficulty = "HARD" }
                    }
                    Text("${stringResource(R.string.question_count)} · $questionCount", style = MaterialTheme.typography.labelLarge, color = cs.onSurface)
                    Slider(value = questionCount.toFloat(), onValueChange = { questionCount = it.toInt() }, valueRange = 1f..5f, steps = 3)
                    OutlinedTextField(
                        value = customQuestions, onValueChange = { customQuestions = it; customQuestionError = false },
                        label = { Text(stringResource(R.string.custom_math_questions)) },
                        supportingText = { Text(if (customQuestionError) stringResource(R.string.custom_math_invalid) else stringResource(R.string.custom_math_format)) },
                        isError = customQuestionError, modifier = Modifier.fillMaxWidth(), minLines = 3, shape = RoundedCornerShape(18.dp)
                    )
                }
                SettingsDivider()
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    SettingsLabel(stringResource(R.string.alarm_summary))
                    Text("%02d:%02d".format(hour, minute), style = MaterialTheme.typography.headlineLarge, color = cs.onSurface, fontWeight = FontWeight.Medium)
                    Text(title.ifBlank { stringResource(R.string.no_alarm_label) }, color = cs.onSurfaceVariant)
                    Text(when {
                        dateInput.isNotBlank() -> dateInput
                        days.isNotEmpty() -> days.sorted().mapNotNull { dayNames.getOrNull(it - 1) }.joinToString(" · ")
                        else -> stringResource(R.string.once)
                    }, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassTextButton(stringResource(R.string.cancel)) { onDismiss() }
                Box(Modifier.weight(1f)) {
                    GlassPrimaryButton(stringResource(R.string.save)) {
                        val customLines = customQuestions.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
                        customQuestionError = math && (customLines.size > 20 || customLines.any { line ->
                            val separator = line.lastIndexOf('|')
                            separator <= 0 || com.alrart.app.domain.MathAnswer.normalizeDigits(line.substring(separator + 1)).toIntOrNull() == null || line.substring(0, separator).isBlank()
                        })
                        if (customQuestionError) return@GlassPrimaryButton
                        val isoDate = if (dateInput.isBlank()) null else runCatching {
                            if (dateCalendar == "JALALI") com.alrart.app.domain.JalaliDate.parse(dateInput)?.toIsoString()
                                ?: throw IllegalArgumentException("Invalid Jalali date")
                            else java.time.LocalDate.parse(dateInput.trim()).toString()
                        }.getOrNull()
                        if (dateInput.isNotBlank() && (isoDate == null || runCatching {
                                val selected = java.time.LocalDate.parse(isoDate)
                                selected.isBefore(java.time.LocalDate.now()) || (selected == java.time.LocalDate.now() && java.time.LocalTime.of(hour, minute) <= java.time.LocalTime.now())
                            }.getOrDefault(true))) { dateError = true; return@GlassPrimaryButton }
                        onSave(AlarmEntity(
                            id = initial?.id ?: 0, hour = hour, minute = minute, enabled = initial?.enabled ?: true,
                            repeatDays = days.sorted().joinToString(","), title = title, note = note,
                            color = color, soundUri = soundUri, vibration = vibration,
                            mathEnabled = math, mathDifficulty = difficulty, mathQuestionCount = questionCount,
                            snoozeMinutes = snooze, customMathQuestions = customQuestions,
                            specificDate = isoDate, dateCalendar = dateCalendar, soundVolume = soundVolume
                        ))
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarPage(alarms: List<AlarmEntity>) {
    var monthOffset by remember { mutableIntStateOf(0) }
    var jalaliMode by remember { mutableStateOf(false) }
    val gregorianMonth = remember(monthOffset, jalaliMode) {
        if (!jalaliMode) java.time.YearMonth.now().plusMonths(monthOffset.toLong()) else null
    }
    val jalaliMonth = remember(monthOffset, jalaliMode) {
        if (jalaliMode) {
            val today = com.alrart.app.domain.JalaliDate.fromGregorian(java.time.LocalDate.now())
            val absoluteMonth = today.year * 12 + (today.month - 1) + monthOffset
            val year = Math.floorDiv(absoluteMonth, 12)
            val month = Math.floorMod(absoluteMonth, 12) + 1
            year to month
        } else null
    }
    val monthStart = remember(gregorianMonth, jalaliMonth) {
        gregorianMonth?.atDay(1) ?: com.alrart.app.domain.JalaliDate(jalaliMonth!!.first, jalaliMonth.second, 1).toGregorian()
    }
    val nextMonthStart = remember(gregorianMonth, jalaliMonth) {
        if (gregorianMonth != null) gregorianMonth.plusMonths(1).atDay(1)
        else {
            val (year, month) = jalaliMonth!!
            val nextIndex = year * 12 + month
            com.alrart.app.domain.JalaliDate(Math.floorDiv(nextIndex, 12), Math.floorMod(nextIndex, 12) + 1, 1).toGregorian()
        }
    }
    val daysInMonth = (nextMonthStart.toEpochDay() - monthStart.toEpochDay()).toInt()
    var selectedDay by remember(monthOffset, jalaliMode) {
        mutableIntStateOf(if (monthOffset == 0) {
            if (jalaliMode) com.alrart.app.domain.JalaliDate.fromGregorian(java.time.LocalDate.now()).day
            else java.time.LocalDate.now().dayOfMonth
        } else 1)
    }
    val selectedDate = monthStart.plusDays((selectedDay.coerceIn(1, daysInMonth) - 1).toLong())

    fun alarmsFor(date: java.time.LocalDate): List<AlarmEntity> = alarms.filter { alarm ->
        if (!alarm.enabled) false
        else if (alarm.specificDate != null) alarm.specificDate == date.toString()
        else if (alarm.repeatDays.isNotBlank()) date.dayOfWeek.value in alarm.repeatDays.split(',').mapNotNull { it.toIntOrNull() }
        else {
            val next = com.alrart.app.domain.AlarmTime.nextOccurrence(alarm, java.time.LocalDateTime.now())
            next != null && java.time.Instant.ofEpochMilli(next).atZone(java.time.ZoneId.systemDefault()).toLocalDate() == date
        }
    }
    val jalaliNames = stringArrayResource(R.array.jalali_months)
    val weekdayNames = if (jalaliMode) listOf(stringResource(R.string.saturday), stringResource(R.string.sunday), stringResource(R.string.monday), stringResource(R.string.tuesday), stringResource(R.string.wednesday), stringResource(R.string.thursday), stringResource(R.string.friday))
        else listOf(stringResource(R.string.monday), stringResource(R.string.tuesday), stringResource(R.string.wednesday), stringResource(R.string.thursday), stringResource(R.string.friday), stringResource(R.string.saturday), stringResource(R.string.sunday))
    val monthTitle = if (jalaliMode) "${jalaliNames[jalaliMonth!!.second - 1]} ${jalaliMonth.first}"
        else gregorianMonth!!.month.getDisplayName(java.time.format.TextStyle.FULL, Locale.getDefault()) + " " + gregorianMonth.year

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text(stringResource(R.string.calendar), style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassChoice(stringResource(R.string.gregorian), selected = !jalaliMode, modifier = Modifier.weight(1f)) { jalaliMode = false; monthOffset = 0 }
            GlassChoice(stringResource(R.string.solar_hijri), selected = jalaliMode, modifier = Modifier.weight(1f)) { jalaliMode = true; monthOffset = 0 }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { monthOffset-- }) { Text("‹") }
            Text(monthTitle, style = MaterialTheme.typography.titleLarge)
            TextButton(onClick = { monthOffset++ }) { Text("›") }
        }
        Text("${alarms.count { it.enabled }}  ·  ${stringResource(R.string.alarms)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
            weekdayNames.forEach { dayName ->
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Text(dayName.take(2), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        val firstOffset = if (jalaliMode) monthStart.dayOfWeek.value % 7 else monthStart.dayOfWeek.value - 1
        val cells = (0 until firstOffset).map { 0 } + (1..daysInMonth).toList()
        cells.chunked(7).forEach { week ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                week.forEach { day ->
                    val date = if (day > 0) monthStart.plusDays((day - 1).toLong()) else null
                    val hasAlarm = date != null && alarmsFor(date).isNotEmpty()
                    val isSelected = day == selectedDay
                    Box(
                        Modifier.weight(1f).padding(3.dp).aspectRatio(1f)
                            .clip(CircleShape)
                            .background(when { isSelected -> MaterialTheme.colorScheme.primary; date == java.time.LocalDate.now() -> MaterialTheme.colorScheme.primaryContainer; else -> Color.Transparent })
                            .clickable(enabled = day > 0) { selectedDay = day },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Text(if (day == 0) "" else day.toString(), color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface)
                            if (hasAlarm) Box(Modifier.size(4.dp).clip(CircleShape).background(if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary))
                        }
                    }
                }
                repeat(7 - week.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        Spacer(Modifier.height(16.dp))
        val selectedLabel = if (jalaliMode) com.alrart.app.domain.JalaliDate.fromGregorian(selectedDate).let { "%04d/%02d/%02d".format(it.year, it.month, it.day) }
            else selectedDate.format(java.time.format.DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.getDefault()))
        Text(selectedLabel, style = MaterialTheme.typography.titleMedium)
        Text(stringResource(R.string.calendar_timezone, java.time.ZoneId.systemDefault().id), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        val dayAlarms = alarmsFor(selectedDate)
        if (dayAlarms.isEmpty()) Text(stringResource(R.string.no_alarms), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
        else dayAlarms.forEach { alarm ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(Color(alarm.color)))
                Spacer(Modifier.width(10.dp))
                Text("%02d:%02d".format(alarm.hour, alarm.minute), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.width(12.dp))
                Text(alarm.title.ifBlank { stringResource(R.string.alarms) }, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun AnalyticsPage(events: List<AlarmEventEntity>) {
    val stats = remember(events) { Statistics.from(events) }
    val weekly = remember(events) {
        (6 downTo 0).map { offset ->
            val date = java.time.LocalDate.now().minusDays(offset.toLong())
            date to events.count { event ->
                event.eventType == "SET" && java.time.Instant.ofEpochMilli(event.occurredAt)
                    .atZone(java.time.ZoneId.systemDefault()).toLocalDate() == date
            }
        }
    }
    val maxCount = (weekly.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
    val barColor = MaterialTheme.colorScheme.primary
    val emptyBarColor = MaterialTheme.colorScheme.surfaceVariant
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(stringResource(R.string.analytics), style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("${stats.setCount}", stringResource(R.string.alarms_created), Modifier.weight(1f))
            StatCard("${stats.snoozeCount}", stringResource(R.string.snooze), Modifier.weight(1f))
        }
        if (events.isEmpty()) Text(stringResource(R.string.no_statistics), color = MaterialTheme.colorScheme.onSurfaceVariant)
        else {
            Text(stringResource(R.string.rings_recorded, stats.ringCount), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(stats.averageDismissMillis?.let { stringResource(R.string.average_dismissal, it / 1000) } ?: stringResource(R.string.no_dismissal_data))
        }
        Text(stringResource(R.string.weekly_activity), style = MaterialTheme.typography.titleMedium)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
            weekly.forEach { (date, count) ->
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(count.toString(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Canvas(Modifier.fillMaxWidth().height(92.dp)) {
                        val barWidth = size.width * 0.52f
                        val barHeight = size.height * (count.toFloat() / maxCount.toFloat()).coerceAtLeast(0.04f)
                        drawRoundRect(
                            color = if (count == 0) emptyBarColor else barColor,
                            topLeft = Offset((size.width - barWidth) / 2f, size.height - barHeight),
                            size = Size(barWidth, barHeight),
                            cornerRadius = CornerRadius(10f, 10f)
                        )
                    }
                    Text(date.format(java.time.format.DateTimeFormatter.ofPattern("EE", Locale.getDefault())), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.58f)),
        shadowElevation = 4.dp
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(value, style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SettingsPage(
    dark: Boolean?, onDark: (Boolean?) -> Unit,
    fontFamily: String, onFont: (String) -> Unit,
    defaultVibration: Boolean, onDefaultVibration: (Boolean) -> Unit,
    defaultSnooze: Int, onDefaultSnooze: (Int) -> Unit,
    defaultSound: String?, onDefaultSound: (String?) -> Unit,
    exactAllowed: Boolean, notificationsAllowed: Boolean,
    onRequestNotifications: () -> Unit, onPermission: () -> Unit,
    onFullScreenPermission: () -> Unit, onTestAlarm: () -> Unit, onTestSoundNow: () -> Unit,
    onLanguage: (String) -> Unit
) {
    val context = LocalContext.current
    val fullScreenAllowed = if (Build.VERSION.SDK_INT >= 34) context.getSystemService(android.app.NotificationManager::class.java).canUseFullScreenIntent() else true
    val activeLocale = AppCompatDelegate.getApplicationLocales().get(0)?.language
        ?: context.resources.configuration.locales[0]?.language ?: "en"
    var diagnostics by remember { mutableStateOf(com.alrart.app.alarm.AlarmDiagnostics.read(context)) }
    LaunchedEffect(Unit) {
        while (true) {
            diagnostics = com.alrart.app.alarm.AlarmDiagnostics.read(context)
            kotlinx.coroutines.delay(1_000L)
        }
    }
    val defaultSoundPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val uri = if (Build.VERSION.SDK_INT >= 33) {
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            }
            onDefaultSound(uri?.toString())
        }
    }
    val cs = MaterialTheme.colorScheme

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("ALART  /  PREFERENCES", style = MaterialTheme.typography.labelSmall, color = cs.primary, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
            Text(stringResource(R.string.settings), style = MaterialTheme.typography.displaySmall, color = cs.onBackground, fontWeight = FontWeight.SemiBold)
            Text(stringResource(R.string.settings_subtitle), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
        }

        SettingsGroup(title = stringResource(R.string.settings_looks)) {
            SettingsLabel(stringResource(R.string.theme))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(null to R.string.theme_auto, false to R.string.light, true to R.string.dark).forEach { (value, label) ->
                    GlassChoice(stringResource(label), selected = dark == value, modifier = Modifier.weight(1f)) { onDark(value) }
                }
            }
            SettingsDivider()
            SettingsLabel(stringResource(R.string.font))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassChoice(stringResource(R.string.font_system_rounded), selected = fontFamily == "sans", modifier = Modifier.weight(1f)) { onFont("sans") }
                GlassChoice(stringResource(R.string.font_serif), selected = fontFamily == "serif", modifier = Modifier.weight(1f)) { onFont("serif") }
            }
            Text(
                stringResource(R.string.font_preview),
                modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                style = MaterialTheme.typography.titleLarge,
                color = cs.onSurface
            )
            Text(stringResource(R.string.theme_appearance_hint), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }

        SettingsGroup(title = stringResource(R.string.language)) {
            Text(stringResource(R.string.language_hint), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassChoice(stringResource(R.string.persian), selected = activeLocale == "fa", modifier = Modifier.weight(1f)) { onLanguage("fa") }
                GlassChoice(stringResource(R.string.english), selected = activeLocale != "fa", modifier = Modifier.weight(1f)) { onLanguage("en") }
            }
        }

        SettingsGroup(title = stringResource(R.string.settings_defaults)) {
            SettingsToggleRow(stringResource(R.string.default_vibration), stringResource(R.string.vibration), defaultVibration, onDefaultVibration)
            SettingsDivider()
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(stringResource(R.string.default_snooze), color = cs.onSurface, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text("$defaultSnooze ${stringResource(R.string.minutes)}", color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
                GlassStepper(value = defaultSnooze, onChange = onDefaultSnooze, min = 1, max = 30)
            }
            SettingsDivider()
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(stringResource(R.string.default_sound), color = cs.onSurface, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(if (defaultSound == null) stringResource(R.string.system_default) else stringResource(R.string.custom_sound_selected), color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
                GlassTextButton(stringResource(R.string.choose_sound)) {
                    val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                        putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                        putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, context.getString(R.string.alarm_sound))
                        putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, defaultSound?.let { Uri.parse(it) })
                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                    }
                    defaultSoundPicker.launch(intent)
                }
            }
            if (defaultSound != null) {
                GlassTextButton(stringResource(R.string.clear_default_sound), danger = true) { onDefaultSound(null) }
            }
        }

        SettingsGroup(title = stringResource(R.string.settings_access)) {
            AccessSettingRow(
                title = stringResource(R.string.exact_alarm_permission), detail = stringResource(R.string.alarm_access_exact_detail),
                allowed = exactAllowed, actionLabel = if (exactAllowed) null else stringResource(R.string.grant_permission), onAction = onPermission
            )
            SettingsDivider()
            AccessSettingRow(
                title = stringResource(R.string.notifications_permission), detail = stringResource(R.string.notification_access_detail),
                allowed = notificationsAllowed, actionLabel = if (!notificationsAllowed && Build.VERSION.SDK_INT >= 33) stringResource(R.string.enable_notifications) else null,
                onAction = onRequestNotifications
            )
            if (Build.VERSION.SDK_INT >= 34) {
                SettingsDivider()
                AccessSettingRow(
                    title = stringResource(R.string.full_screen_permission), detail = stringResource(R.string.full_screen_access_detail),
                    allowed = fullScreenAllowed, actionLabel = if (fullScreenAllowed) null else stringResource(R.string.grant_permission),
                    onAction = onFullScreenPermission
                )
            }
        }

        SettingsGroup(title = stringResource(R.string.settings_support)) {
            Text(stringResource(R.string.sound_test_hint), color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            GlassPrimaryButton(stringResource(R.string.test_sound_now), onClick = onTestSoundNow)
            GlassTextButton(stringResource(R.string.test_alarm_button), onClick = onTestAlarm)
            SettingsDivider()
            SettingsLabel(stringResource(R.string.diagnostics_last_event))
            Text(diagnostics, color = cs.onSurface, style = MaterialTheme.typography.bodySmall, lineHeight = 20.sp)
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun SettingsLabel(text: String) {
    Text(text.uppercase(), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold, letterSpacing = 1.0.sp)
}

@Composable
private fun SettingsDivider() {
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.48f), thickness = 0.7.dp)
}

@Composable
private fun GlassChoice(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier.clip(RoundedCornerShape(18.dp))
            .background(if (selected) Brush.linearGradient(listOf(cs.primary.copy(alpha = 0.22f), cs.tertiary.copy(alpha = 0.14f))) else Brush.linearGradient(listOf(cs.surface.copy(alpha = 0.48f), cs.surfaceVariant.copy(alpha = 0.44f))))
            .border(1.dp, if (selected) cs.primary.copy(alpha = 0.55f) else cs.outlineVariant.copy(alpha = 0.55f), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        Text(text, color = if (selected) cs.primary else cs.onSurface, style = MaterialTheme.typography.labelLarge, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun SettingsToggleRow(title: String, detail: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(detail, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked = checked, onCheckedChange = onChecked, colors = SwitchDefaults.colors(
            checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
            checkedTrackColor = MaterialTheme.colorScheme.primary,
            uncheckedThumbColor = MaterialTheme.colorScheme.onSurfaceVariant,
            uncheckedTrackColor = MaterialTheme.colorScheme.surfaceVariant
        ))
    }
}

@Composable
private fun GlassStepper(value: Int, onChange: (Int) -> Unit, min: Int, max: Int) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.clip(RoundedCornerShape(16.dp)).background(cs.surfaceVariant.copy(alpha = 0.62f)).border(1.dp, cs.outlineVariant.copy(alpha = 0.55f), RoundedCornerShape(16.dp)).padding(3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("−", modifier = Modifier.clip(CircleShape).clickable(enabled = value > min) { onChange(value - 1) }.padding(horizontal = 12.dp, vertical = 6.dp), color = cs.onSurface, style = MaterialTheme.typography.titleLarge)
        Text(value.toString(), modifier = Modifier.widthIn(min = 22.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = cs.onSurface, fontWeight = FontWeight.Bold)
        Text("+", modifier = Modifier.clip(CircleShape).clickable(enabled = value < max) { onChange(value + 1) }.padding(horizontal = 12.dp, vertical = 6.dp), color = cs.onSurface, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
private fun GlassTextButton(text: String, danger: Boolean = false, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Text(text, modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(cs.surfaceVariant.copy(alpha = 0.65f)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp), color = if (danger) cs.error else cs.primary, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun GlassPrimaryButton(text: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(cs.primary, cs.tertiary))).clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        Text(text, color = cs.onPrimary, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SettingsLabel(title)
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                .background(Brush.verticalGradient(listOf(cs.surface.copy(alpha = 0.84f), cs.surfaceVariant.copy(alpha = 0.48f))))
                .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.68f), cs.outlineVariant.copy(alpha = 0.56f))), RoundedCornerShape(28.dp))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            content = content
        )
    }
}

@Composable
private fun AccessSettingRow(title: String, detail: String, allowed: Boolean, actionLabel: String?, onAction: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(if (allowed) cs.primary else cs.error))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = cs.onSurface)
            Text(detail, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, lineHeight = 18.sp)
            Text(stringResource(if (allowed) R.string.access_allowed else R.string.access_denied), style = MaterialTheme.typography.labelSmall,
                color = if (allowed) cs.primary else cs.error, fontWeight = FontWeight.Bold)
        }
        if (actionLabel != null) GlassTextButton(actionLabel, onClick = onAction)
    }
}
