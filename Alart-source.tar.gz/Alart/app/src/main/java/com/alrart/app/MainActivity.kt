package com.alrart.app

import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.core.app.NotificationManagerCompat
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.activity.compose.rememberLauncherForActivityResult
import com.alrart.app.alarm.AlarmScheduler
import com.alrart.app.data.AlarmEntity
import com.alrart.app.data.SettingsStore
import com.alrart.app.data.AlarmEventEntity
import com.alrart.app.domain.Statistics
import com.alrart.app.ui.theme.AlartTheme
import com.alrart.app.widget.AlartWidget
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope
import java.time.LocalTime
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val settings = remember { SettingsStore(applicationContext) }
            val themeMode by settings.themeMode.collectAsState(initial = "system")
            val fontFamily by settings.fontFamily.collectAsState(initial = "sans")
            val defaultVibration by settings.defaultVibration.collectAsState(initial = true)
            val defaultSnooze by settings.defaultSnoozeMinutes.collectAsState(initial = 5)
            val defaultSound by settings.defaultSoundUri.collectAsState(initial = null)
            val selectedDark = when (themeMode) { "dark" -> true; "light" -> false; else -> null }
            AlartTheme(darkTheme = selectedDark ?: androidx.compose.foundation.isSystemInDarkTheme(), fontChoice = fontFamily) {
                AlartApp(dark = selectedDark, fontFamily = fontFamily, defaultVibration = defaultVibration, defaultSnooze = defaultSnooze, defaultSound = defaultSound,
                    onFont = { value -> lifecycleScope.launch { settings.setFontFamily(value) } },
                    onDefaultVibration = { value -> lifecycleScope.launch { settings.setDefaultVibration(value) } },
                    onDefaultSnooze = { value -> lifecycleScope.launch { settings.setDefaultSnoozeMinutes(value) } },
                    onDefaultSound = { value -> lifecycleScope.launch { settings.setDefaultSoundUri(value) } }, onRequestNotifications = {
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) notificationPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                }, onDark = { value ->
                    lifecycleScope.launch { settings.setThemeMode(when (value) { true -> "dark"; false -> "light"; null -> "system" }) }
                })
            }
        }
    }
}

private enum class Destination { ALARMS, CALENDAR, ANALYTICS, SETTINGS }

@Composable
private fun AlartApp(
    dark: Boolean?, fontFamily: String, defaultVibration: Boolean, defaultSnooze: Int, defaultSound: String?,
    onFont: (String) -> Unit, onDefaultVibration: (Boolean) -> Unit, onDefaultSnooze: (Int) -> Unit,
    onDefaultSound: (String?) -> Unit, onRequestNotifications: () -> Unit, onDark: (Boolean?) -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as AlartApplication
    val dao = remember { app.database.alarmDao() }
    val alarms by dao.observeAll().collectAsState(initial = emptyList())
    val events by dao.observeEvents().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var destination by remember { mutableStateOf(Destination.ALARMS) }
    var editor by remember { mutableStateOf<AlarmEntity?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val scheduler = remember { AlarmScheduler(context) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(message) { message?.let { snackbar.showSnackbar(it); message = null } }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        floatingActionButton = {
            if (destination == Destination.ALARMS) FloatingActionButton(onClick = { editor = null; showEditor = true }, containerColor = MaterialTheme.colorScheme.primary) {
                Icon(Icons.Rounded.Add, contentDescription = stringResource(R.string.add_alarm), tint = MaterialTheme.colorScheme.onPrimary)
            }
        },
        bottomBar = {
            Surface(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                shape = RoundedCornerShape(30.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 5.dp,
                shadowElevation = 8.dp
            ) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    NavigationBarItem(selected = destination == Destination.ALARMS, onClick = { destination = Destination.ALARMS }, icon = { Icon(Icons.Rounded.Alarm, null) }, label = { Text(stringResource(R.string.alarms)) })
                    NavigationBarItem(selected = destination == Destination.CALENDAR, onClick = { destination = Destination.CALENDAR }, icon = { Icon(Icons.Rounded.CalendarMonth, null) }, label = { Text(stringResource(R.string.calendar)) })
                    NavigationBarItem(selected = destination == Destination.ANALYTICS, onClick = { destination = Destination.ANALYTICS }, icon = { Icon(Icons.Rounded.Insights, null) }, label = { Text(stringResource(R.string.analytics)) })
                    NavigationBarItem(selected = destination == Destination.SETTINGS, onClick = { destination = Destination.SETTINGS }, icon = { Icon(Icons.Rounded.Settings, null) }, label = { Text(stringResource(R.string.settings)) })
                }
            }
        }
    ) { padding ->
        AnimatedContent(destination, modifier = Modifier.padding(padding), label = "main_navigation") { page ->
            when (page) {
                Destination.ALARMS -> AlarmHome(alarms, onToggle = { alarm, enabled ->
                    scope.launch {
                        dao.setEnabled(alarm.id, enabled)
                        val updated = alarm.copy(enabled = enabled, nextTriggerAt = null)
                        val scheduledAt = scheduler.schedule(updated)
                        if (scheduledAt == null) {
                            dao.setEnabled(alarm.id, false)
                            dao.setNextTrigger(alarm.id, null)
                            message = context.getString(R.string.permission_needed)
                        } else {
                            dao.setNextTrigger(alarm.id, scheduledAt.takeIf { it > 0L })
                        }
                        if (!enabled) NotificationManagerCompat.from(context).cancel(alarm.id.toInt())
                        refreshAlartWidget(context)
                    }
                }, onEdit = { editor = it; showEditor = true }, onDelete = { alarm -> scope.launch { scheduler.cancel(alarm.id); NotificationManagerCompat.from(context).cancel(alarm.id.toInt()); dao.delete(alarm.id); refreshAlartWidget(context) } })
                Destination.CALENDAR -> CalendarPage(alarms)
                Destination.ANALYTICS -> AnalyticsPage(events)
                Destination.SETTINGS -> SettingsPage(
                    dark, onDark, fontFamily, onFont, defaultVibration, onDefaultVibration, defaultSnooze, onDefaultSnooze, defaultSound, onDefaultSound, onRequestNotifications,
                    onLanguage = { tag -> AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag)) },
                    onPermission = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) context.startActivity(Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}")))
                    },
                    onFullScreenPermission = {
                        if (Build.VERSION.SDK_INT >= 34) context.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${context.packageName}")))
                    }
                )
            }
        }
    }

    if (showEditor) {
        AlarmEditorDialog(initial = editor, defaultVibration = defaultVibration, defaultSnooze = defaultSnooze, defaultSound = defaultSound, onDismiss = { showEditor = false }, onSave = { alarm ->
            scope.launch {
                val id = dao.upsert(alarm)
                val saved = alarm.copy(id = if (alarm.id == 0L) id else alarm.id)
                val scheduledAt = scheduler.schedule(saved)
                if (scheduledAt == null) {
                    dao.setEnabled(saved.id, false)
                    dao.setNextTrigger(saved.id, null)
                    message = context.getString(R.string.permission_needed)
                } else {
                    dao.setNextTrigger(saved.id, scheduledAt.takeIf { it > 0L })
                    if (alarm.id == 0L) dao.addEvent(AlarmEventEntity(alarmId = saved.id, eventType = "SET", occurredAt = System.currentTimeMillis()))
                    message = context.getString(R.string.alarm_saved)
                }
                refreshAlartWidget(context)
                showEditor = false
            }
        })
    }
}

private suspend fun refreshAlartWidget(context: android.content.Context) {
    try { AlartWidget().updateAll(context) } catch (_: Exception) { }
}

@Composable
private fun AlarmHome(alarms: List<AlarmEntity>, onToggle: (AlarmEntity, Boolean) -> Unit, onEdit: (AlarmEntity) -> Unit, onDelete: (AlarmEntity) -> Unit) {
    val now = remember { mutableStateOf(LocalTime.now()) }
    LaunchedEffect(Unit) { while (true) { now.value = LocalTime.now(); kotlinx.coroutines.delay(30_000) } }
    val upcoming = alarms.filter { it.enabled }.minByOrNull { alarm ->
        com.alrart.app.domain.AlarmTime.nextOccurrence(alarm, java.time.LocalDateTime.now()) ?: Long.MAX_VALUE
    }
    val weekdayNames = listOf(stringResource(R.string.monday), stringResource(R.string.tuesday), stringResource(R.string.wednesday), stringResource(R.string.thursday), stringResource(R.string.friday), stringResource(R.string.saturday), stringResource(R.string.sunday))
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp)) {
        Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("%02d:%02d".format(now.value.hour, now.value.minute), style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(18.dp))
        Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(22.dp)) {
                Text(stringResource(R.string.next_alarm), color = MaterialTheme.colorScheme.onPrimaryContainer)
                Spacer(Modifier.height(8.dp))
                Text(upcoming?.let { "%02d:%02d".format(it.hour, it.minute) } ?: "--:--", style = MaterialTheme.typography.displayMedium, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Light)
                val upcomingTitle = upcoming?.title?.takeIf { it.isNotBlank() } ?: stringResource(R.string.no_alarms)
                Text(upcomingTitle, color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }
        Spacer(Modifier.height(22.dp))
        Text(stringResource(R.string.alarms), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        if (alarms.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(stringResource(R.string.no_alarms), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
            items(alarms, key = { it.id }) { alarm ->
                Card(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth().clickable { onEdit(alarm) }) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(Color(alarm.color)))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("%02d:%02d".format(alarm.hour, alarm.minute), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Medium)
                            Text(alarm.title.takeIf { it.isNotBlank() } ?: stringResource(R.string.alarms), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            val scheduleLabel = when {
                                alarm.specificDate != null -> runCatching {
                                    val date = java.time.LocalDate.parse(alarm.specificDate)
                                    if (alarm.dateCalendar == "JALALI") com.alrart.app.domain.JalaliDate.fromGregorian(date).let { "%04d/%02d/%02d".format(it.year, it.month, it.day) }
                                    else date.toString()
                                }.getOrDefault(alarm.specificDate)
                                alarm.repeatDays.isNotBlank() -> alarm.repeatDays.split(',').mapNotNull { it.toIntOrNull()?.minus(1) }.mapNotNull { weekdayNames.getOrNull(it) }.joinToString(" · ")
                                else -> stringResource(R.string.once)
                            }
                            Text(scheduleLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }
                        Switch(checked = alarm.enabled, onCheckedChange = { onToggle(alarm, it) })
                        TextButton(onClick = { onDelete(alarm) }) { Text(stringResource(R.string.delete)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun AlarmEditorDialog(initial: AlarmEntity?, defaultVibration: Boolean, defaultSnooze: Int, defaultSound: String?, onDismiss: () -> Unit, onSave: (AlarmEntity) -> Unit) {
    val context = LocalContext.current
    var hour by remember { mutableIntStateOf(initial?.hour ?: 7) }
    var minute by remember { mutableIntStateOf(initial?.minute ?: 0) }
    var title by remember { mutableStateOf(initial?.title.orEmpty()) }
    var note by remember { mutableStateOf(initial?.note.orEmpty()) }
    var days by remember { mutableStateOf(initial?.repeatDays?.split(',')?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()) }
    var vibration by remember(initial?.id) { mutableStateOf(initial?.vibration ?: defaultVibration) }
    var math by remember { mutableStateOf(initial?.mathEnabled ?: false) }
    var difficulty by remember { mutableStateOf(initial?.mathDifficulty ?: "EASY") }
    var questionCount by remember { mutableIntStateOf(initial?.mathQuestionCount ?: 2) }
    var customQuestions by remember { mutableStateOf(initial?.customMathQuestions.orEmpty()) }
    var snooze by remember(initial?.id) { mutableIntStateOf(initial?.snoozeMinutes ?: defaultSnooze) }
    var color by remember { mutableLongStateOf(initial?.color ?: 0xFF6658D3) }
    var soundUri by remember(initial?.id) { mutableStateOf(if (initial == null) defaultSound else initial.soundUri) }
    var soundVolume by remember(initial?.id) { mutableIntStateOf(initial?.soundVolume ?: 100) }
    var dateCalendar by remember { mutableStateOf(initial?.dateCalendar ?: "GREGORIAN") }
    var dateInput by remember(initial?.id) {
        mutableStateOf(initial?.specificDate?.let { iso ->
            runCatching {
                val date = java.time.LocalDate.parse(iso)
                if (dateCalendar == "JALALI") com.alrart.app.domain.JalaliDate.fromGregorian(date).let { "%04d/%02d/%02d".format(it.year, it.month, it.day) }
                else iso
            }.getOrDefault(iso)
        } ?: "")
    }
    var dateError by remember { mutableStateOf(false) }
    var customQuestionError by remember { mutableStateOf(false) }
    fun switchDateCalendar(target: String) {
        if (target == dateCalendar) return
        if (dateInput.isNotBlank()) {
            val gregorian = runCatching {
                if (dateCalendar == "JALALI") com.alrart.app.domain.JalaliDate.parse(dateInput)?.toGregorian()
                else java.time.LocalDate.parse(dateInput.trim())
            }.getOrNull()
            if (gregorian != null) {
                dateInput = if (target == "JALALI") com.alrart.app.domain.JalaliDate.fromGregorian(gregorian).let { "%04d/%02d/%02d".format(it.year, it.month, it.day) } else gregorian.toString()
            }
        }
        dateCalendar = target
    }
    val soundPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            soundUri = result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)?.toString()
        }
    }
    val colors = listOf(0xFF6658D3, 0xFF168C78, 0xFFE07838, 0xFFD34F70, 0xFF3977C5, 0xFF8A8F98)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) stringResource(R.string.add_alarm) else stringResource(R.string.edit_alarm)) },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { TimePickerDialog(context, { _, h, m -> hour = h; minute = m }, hour, minute, true).show() }, modifier = Modifier.fillMaxWidth()) {
                    Text("%02d:%02d".format(hour, minute), style = MaterialTheme.typography.headlineMedium)
                }
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text(stringResource(R.string.alarm_title)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text(stringResource(R.string.alarm_note)) }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                Text(stringResource(R.string.repeat), style = MaterialTheme.typography.labelLarge)
                Text(stringResource(R.string.specific_date), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = dateCalendar == "GREGORIAN", onClick = { switchDateCalendar("GREGORIAN") }, label = { Text(stringResource(R.string.gregorian)) })
                    FilterChip(selected = dateCalendar == "JALALI", onClick = { switchDateCalendar("JALALI") }, label = { Text(stringResource(R.string.solar_hijri)) })
                }
                OutlinedTextField(
                    value = dateInput,
                    onValueChange = { dateInput = it; dateError = false; if (it.isNotBlank()) days = emptySet() },
                    label = { Text(if (dateCalendar == "JALALI") stringResource(R.string.jalali_date_format) else stringResource(R.string.gregorian_date_format)) },
                    supportingText = { Text(stringResource(if (dateError) R.string.date_future_error else R.string.date_once_hint)) },
                    isError = dateError,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                val dayLabels = listOf(R.string.monday, R.string.tuesday, R.string.wednesday, R.string.thursday, R.string.friday, R.string.saturday, R.string.sunday)
                val dayNames = dayLabels.map { stringResource(it) }
                dayLabels.forEachIndexed { index, label ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = index + 1 in days, onCheckedChange = { checked ->
                            days = if (checked) days + (index + 1) else days - (index + 1)
                            if (checked) { dateInput = ""; dateError = false }
                        })
                        Text(stringResource(label))
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(vibration, { vibration = it }); Text(stringResource(R.string.vibration)) }
                Text(stringResource(R.string.alarm_color), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    colors.forEach { swatch ->
                        Box(Modifier.size(34.dp).clip(CircleShape).background(Color(swatch)).clickable { color = swatch }, contentAlignment = Alignment.Center) {
                            if (color == swatch) Text("✓", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                OutlinedButton(onClick = {
                    val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                        putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                        putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, context.getString(R.string.alarm_sound))
                        putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, soundUri?.let { Uri.parse(it) })
                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                    }
                    soundPicker.launch(intent)
                }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.choose_sound)) }
                Text("${stringResource(R.string.sound_volume)}: $soundVolume%", style = MaterialTheme.typography.labelLarge)
                Slider(value = soundVolume.toFloat(), onValueChange = { soundVolume = it.toInt() }, valueRange = 0f..100f, steps = 19)
                Text(stringResource(R.string.sound_volume_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton(onClick = {
                    runCatching { context.startActivity(Intent(android.provider.Settings.ACTION_SOUND_SETTINGS)) }
                }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.open_sound_settings)) }
                Text("${stringResource(R.string.snooze_duration)}: $snooze ${stringResource(R.string.minutes)}")
                Slider(value = snooze.toFloat(), onValueChange = { snooze = it.toInt() }, valueRange = 1f..30f, steps = 28)
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(math, { math = it }); Text(stringResource(R.string.math_dismissal)) }
                if (math) {
                    Text(stringResource(R.string.math_difficulty), style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = difficulty == "EASY", onClick = { difficulty = "EASY" }, label = { Text(stringResource(R.string.easy)) })
                        FilterChip(selected = difficulty == "MEDIUM", onClick = { difficulty = "MEDIUM" }, label = { Text(stringResource(R.string.medium)) })
                        FilterChip(selected = difficulty == "HARD", onClick = { difficulty = "HARD" }, label = { Text(stringResource(R.string.hard)) })
                    }
                    Text("${stringResource(R.string.question_count)}: $questionCount")
                    Slider(value = questionCount.toFloat(), onValueChange = { questionCount = it.toInt() }, valueRange = 1f..5f, steps = 3)
                    OutlinedTextField(
                        value = customQuestions,
                        onValueChange = { customQuestions = it; customQuestionError = false },
                        label = { Text(stringResource(R.string.custom_math_questions)) },
                        supportingText = { Text(if (customQuestionError) stringResource(R.string.custom_math_invalid) else stringResource(R.string.custom_math_format)) },
                        isError = customQuestionError,
                        modifier = Modifier.fillMaxWidth(), minLines = 3
                    )
                }
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text(stringResource(R.string.alarm_summary), style = MaterialTheme.typography.titleSmall)
                        Text("%02d:%02d".format(hour, minute), style = MaterialTheme.typography.titleLarge)
                        Text(title.ifBlank { stringResource(R.string.no_alarm_label) })
                        Text(when {
                            dateInput.isNotBlank() -> dateInput
                            days.isNotEmpty() -> days.sorted().mapNotNull { dayNames.getOrNull(it - 1) }.joinToString(", ")
                            else -> stringResource(R.string.once)
                        }, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = {
            val customLines = customQuestions.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
            customQuestionError = math && (customLines.size > 20 || customLines.any { line ->
                val separator = line.lastIndexOf('|')
                separator <= 0 || com.alrart.app.domain.MathAnswer.normalizeDigits(line.substring(separator + 1)).toIntOrNull() == null || line.substring(0, separator).isBlank()
            })
            if (customQuestionError) return@TextButton
            val isoDate = if (dateInput.isBlank()) null else runCatching {
                if (dateCalendar == "JALALI") com.alrart.app.domain.JalaliDate.parse(dateInput)?.toIsoString()
                    ?: throw IllegalArgumentException("Invalid Jalali date")
                else java.time.LocalDate.parse(dateInput.trim()).toString()
            }.getOrNull()
            if (dateInput.isNotBlank() && (isoDate == null || runCatching {
                    val selected = java.time.LocalDate.parse(isoDate)
                    selected.isBefore(java.time.LocalDate.now()) || (selected == java.time.LocalDate.now() && java.time.LocalTime.of(hour, minute) <= java.time.LocalTime.now())
                }.getOrDefault(true))) { dateError = true; return@TextButton }
            onSave(AlarmEntity(
                id = initial?.id ?: 0, hour = hour, minute = minute, enabled = initial?.enabled ?: true,
                repeatDays = days.sorted().joinToString(","), title = title, note = note,
                color = color, soundUri = soundUri, vibration = vibration,
                mathEnabled = math, mathDifficulty = difficulty, mathQuestionCount = questionCount,
                snoozeMinutes = snooze, customMathQuestions = customQuestions,
                specificDate = isoDate, dateCalendar = dateCalendar, soundVolume = soundVolume
            ))
        }) { Text(stringResource(R.string.save)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}

@Composable
private fun CalendarPage(alarms: List<AlarmEntity>) {
    var monthOffset by remember { mutableIntStateOf(0) }
    var jalaliMode by remember { mutableStateOf(false) }
    val gregorianMonth = remember(monthOffset, jalaliMode) {
        if (!jalaliMode) java.time.YearMonth.now().plusMonths(monthOffset.toLong()) else null
    }
    val jalaliMonth = remember(monthOffset, jalaliMode) {
        if (jalaliMode) {
            val today = com.alrart.app.domain.JalaliDate.fromGregorian(java.time.LocalDate.now())
            val absoluteMonth = today.year * 12 + (today.month - 1) + monthOffset
            val year = Math.floorDiv(absoluteMonth, 12)
            val month = Math.floorMod(absoluteMonth, 12) + 1
            year to month
        } else null
    }
    val monthStart = remember(gregorianMonth, jalaliMonth) {
        gregorianMonth?.atDay(1) ?: com.alrart.app.domain.JalaliDate(jalaliMonth!!.first, jalaliMonth.second, 1).toGregorian()
    }
    val nextMonthStart = remember(gregorianMonth, jalaliMonth) {
        if (gregorianMonth != null) gregorianMonth.plusMonths(1).atDay(1)
        else {
            val (year, month) = jalaliMonth!!
            val nextIndex = year * 12 + month
            com.alrart.app.domain.JalaliDate(Math.floorDiv(nextIndex, 12), Math.floorMod(nextIndex, 12) + 1, 1).toGregorian()
        }
    }
    val daysInMonth = (nextMonthStart.toEpochDay() - monthStart.toEpochDay()).toInt()
    var selectedDay by remember(monthOffset, jalaliMode) {
        mutableIntStateOf(if (monthOffset == 0) {
            if (jalaliMode) com.alrart.app.domain.JalaliDate.fromGregorian(java.time.LocalDate.now()).day
            else java.time.LocalDate.now().dayOfMonth
        } else 1)
    }
    val selectedDate = monthStart.plusDays((selectedDay.coerceIn(1, daysInMonth) - 1).toLong())

    fun alarmsFor(date: java.time.LocalDate): List<AlarmEntity> = alarms.filter { alarm ->
        if (!alarm.enabled) false
        else if (alarm.specificDate != null) alarm.specificDate == date.toString()
        else if (alarm.repeatDays.isNotBlank()) date.dayOfWeek.value in alarm.repeatDays.split(',').mapNotNull { it.toIntOrNull() }
        else {
            val next = com.alrart.app.domain.AlarmTime.nextOccurrence(alarm, java.time.LocalDateTime.now())
            next != null && java.time.Instant.ofEpochMilli(next).atZone(java.time.ZoneId.systemDefault()).toLocalDate() == date
        }
    }
    val jalaliNames = stringArrayResource(R.array.jalali_months)
    val weekdayNames = if (jalaliMode) listOf(stringResource(R.string.saturday), stringResource(R.string.sunday), stringResource(R.string.monday), stringResource(R.string.tuesday), stringResource(R.string.wednesday), stringResource(R.string.thursday), stringResource(R.string.friday))
        else listOf(stringResource(R.string.monday), stringResource(R.string.tuesday), stringResource(R.string.wednesday), stringResource(R.string.thursday), stringResource(R.string.friday), stringResource(R.string.saturday), stringResource(R.string.sunday))
    val monthTitle = if (jalaliMode) "${jalaliNames[jalaliMonth!!.second - 1]} ${jalaliMonth.first}"
        else gregorianMonth!!.month.getDisplayName(java.time.format.TextStyle.FULL, Locale.getDefault()) + " " + gregorianMonth.year

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text(stringResource(R.string.calendar), style = MaterialTheme.typography.headlineMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !jalaliMode, onClick = { jalaliMode = false; monthOffset = 0 }, label = { Text(stringResource(R.string.gregorian)) })
            FilterChip(selected = jalaliMode, onClick = { jalaliMode = true; monthOffset = 0 }, label = { Text(stringResource(R.string.solar_hijri)) })
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { monthOffset-- }) { Text("‹") }
            Text(monthTitle, style = MaterialTheme.typography.titleLarge)
            TextButton(onClick = { monthOffset++ }) { Text("›") }
        }
        Text("${alarms.count { it.enabled }}  ·  ${stringResource(R.string.alarms)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
            weekdayNames.forEach { dayName ->
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Text(dayName.take(2), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        val firstOffset = if (jalaliMode) monthStart.dayOfWeek.value % 7 else monthStart.dayOfWeek.value - 1
        val cells = (0 until firstOffset).map { 0 } + (1..daysInMonth).toList()
        cells.chunked(7).forEach { week ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                week.forEach { day ->
                    val date = if (day > 0) monthStart.plusDays((day - 1).toLong()) else null
                    val hasAlarm = date != null && alarmsFor(date).isNotEmpty()
                    val isSelected = day == selectedDay
                    Box(
                        Modifier.weight(1f).padding(3.dp).aspectRatio(1f)
                            .clip(CircleShape)
                            .background(when { isSelected -> MaterialTheme.colorScheme.primary; date == java.time.LocalDate.now() -> MaterialTheme.colorScheme.primaryContainer; else -> Color.Transparent })
                            .clickable(enabled = day > 0) { selectedDay = day },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Text(if (day == 0) "" else day.toString(), color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface)
                            if (hasAlarm) Box(Modifier.size(4.dp).clip(CircleShape).background(if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary))
                        }
                    }
                }
                repeat(7 - week.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        Spacer(Modifier.height(16.dp))
        val selectedLabel = if (jalaliMode) com.alrart.app.domain.JalaliDate.fromGregorian(selectedDate).let { "%04d/%02d/%02d".format(it.year, it.month, it.day) }
            else selectedDate.format(java.time.format.DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.getDefault()))
        Text(selectedLabel, style = MaterialTheme.typography.titleMedium)
        Text(stringResource(R.string.calendar_timezone, java.time.ZoneId.systemDefault().id), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        val dayAlarms = alarmsFor(selectedDate)
        if (dayAlarms.isEmpty()) Text(stringResource(R.string.no_alarms), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
        else dayAlarms.forEach { alarm ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(Color(alarm.color)))
                Spacer(Modifier.width(10.dp))
                Text("%02d:%02d".format(alarm.hour, alarm.minute), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.width(12.dp))
                Text(alarm.title.ifBlank { stringResource(R.string.alarms) }, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun AnalyticsPage(events: List<AlarmEventEntity>) {
    val stats = remember(events) { Statistics.from(events) }
    val weekly = remember(events) {
        (6 downTo 0).map { offset ->
            val date = java.time.LocalDate.now().minusDays(offset.toLong())
            date to events.count { event ->
                event.eventType == "SET" && java.time.Instant.ofEpochMilli(event.occurredAt)
                    .atZone(java.time.ZoneId.systemDefault()).toLocalDate() == date
            }
        }
    }
    val maxCount = (weekly.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
    val barColor = MaterialTheme.colorScheme.primary
    val emptyBarColor = MaterialTheme.colorScheme.surfaceVariant
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(stringResource(R.string.analytics), style = MaterialTheme.typography.headlineMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("${stats.setCount}", stringResource(R.string.alarms_created), Modifier.weight(1f))
            StatCard("${stats.snoozeCount}", stringResource(R.string.snooze), Modifier.weight(1f))
        }
        if (events.isEmpty()) Text(stringResource(R.string.no_statistics), color = MaterialTheme.colorScheme.onSurfaceVariant)
        else {
            Text(stringResource(R.string.rings_recorded, stats.ringCount), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(stats.averageDismissMillis?.let { stringResource(R.string.average_dismissal, it / 1000) } ?: stringResource(R.string.no_dismissal_data))
        }
        Text(stringResource(R.string.weekly_activity), style = MaterialTheme.typography.titleMedium)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
            weekly.forEach { (date, count) ->
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(count.toString(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Canvas(Modifier.fillMaxWidth().height(92.dp)) {
                        val barWidth = size.width * 0.52f
                        val barHeight = size.height * (count.toFloat() / maxCount.toFloat()).coerceAtLeast(0.04f)
                        drawRoundRect(
                            color = if (count == 0) emptyBarColor else barColor,
                            topLeft = Offset((size.width - barWidth) / 2f, size.height - barHeight),
                            size = Size(barWidth, barHeight),
                            cornerRadius = CornerRadius(10f, 10f)
                        )
                    }
                    Text(date.format(java.time.format.DateTimeFormatter.ofPattern("EE", Locale.getDefault())), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(22.dp)) { Column(Modifier.padding(18.dp)) { Text(value, style = MaterialTheme.typography.headlineMedium); Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
}

@Composable
private fun SettingsPage(
    dark: Boolean?, onDark: (Boolean?) -> Unit, fontFamily: String, onFont: (String) -> Unit,
    defaultVibration: Boolean, onDefaultVibration: (Boolean) -> Unit, defaultSnooze: Int, onDefaultSnooze: (Int) -> Unit,
    defaultSound: String?, onDefaultSound: (String?) -> Unit, onRequestNotifications: () -> Unit,
    onLanguage: (String) -> Unit, onPermission: () -> Unit, onFullScreenPermission: () -> Unit
) {
    val context = LocalContext.current
    val exactAllowed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) context.getSystemService(android.app.AlarmManager::class.java).canScheduleExactAlarms() else true
    val notificationsAllowed = NotificationManagerCompat.from(context).areNotificationsEnabled()
    val fullScreenAllowed = if (Build.VERSION.SDK_INT >= 34) context.getSystemService(android.app.NotificationManager::class.java).canUseFullScreenIntent() else true
    val defaultSoundPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val uri = result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI) as? Uri
            onDefaultSound(uri?.toString())
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.settings), style = MaterialTheme.typography.headlineMedium)
        Text(stringResource(R.string.theme), style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = dark == null, onClick = { onDark(null) }, label = { Text(stringResource(R.string.system)) })
            FilterChip(selected = dark == false, onClick = { onDark(false) }, label = { Text(stringResource(R.string.light)) })
            FilterChip(selected = dark == true, onClick = { onDark(true) }, label = { Text(stringResource(R.string.dark)) })
        }
        Text(stringResource(R.string.font), style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = fontFamily == "sans", onClick = { onFont("sans") }, label = { Text(stringResource(R.string.font_sans)) })
            FilterChip(selected = fontFamily == "serif", onClick = { onFont("serif") }, label = { Text(stringResource(R.string.font_serif)) })
            FilterChip(selected = fontFamily == "mono", onClick = { onFont("mono") }, label = { Text(stringResource(R.string.font_mono)) })
            FilterChip(selected = fontFamily == "cursive", onClick = { onFont("cursive") }, label = { Text(stringResource(R.string.font_cursive)) })
        }
        Text(stringResource(R.string.font_preview), style = MaterialTheme.typography.bodyMedium)
        Text(stringResource(R.string.default_alarm_settings), style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = defaultVibration, onCheckedChange = onDefaultVibration)
            Text(stringResource(R.string.default_vibration))
        }
        Text("${stringResource(R.string.default_snooze)}: $defaultSnooze ${stringResource(R.string.minutes)}")
        Slider(value = defaultSnooze.toFloat(), onValueChange = { onDefaultSnooze(it.toInt()) }, valueRange = 1f..30f, steps = 28)
        OutlinedButton(onClick = {
            val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, context.getString(R.string.alarm_sound))
                putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, defaultSound?.let { Uri.parse(it) })
                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
            }
            defaultSoundPicker.launch(intent)
        }) { Text(stringResource(R.string.default_sound)) }
        OutlinedButton(onClick = {
            runCatching { context.startActivity(Intent(android.provider.Settings.ACTION_SOUND_SETTINGS)) }
        }) { Text(stringResource(R.string.open_sound_settings)) }
        if (defaultSound != null) TextButton(onClick = { onDefaultSound(null) }) { Text(stringResource(R.string.clear_default_sound)) }
        Text(stringResource(R.string.language), style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { onLanguage("fa") }) { Text(stringResource(R.string.persian)) }
            OutlinedButton(onClick = { onLanguage("en") }) { Text(stringResource(R.string.english)) }
        }
        Text(stringResource(R.string.permissions), style = MaterialTheme.typography.titleMedium)
        Text(stringResource(if (exactAllowed) R.string.permission_granted else R.string.permission_denied, stringResource(R.string.exact_alarm_permission)))
        Button(onClick = onPermission, enabled = !exactAllowed) { Text(stringResource(R.string.grant_permission)) }
        Text(stringResource(if (notificationsAllowed) R.string.permission_granted else R.string.permission_denied, stringResource(R.string.notifications_permission)))
        Text(stringResource(R.string.notifications_permission_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedButton(onClick = onRequestNotifications, enabled = Build.VERSION.SDK_INT >= 33 && !notificationsAllowed) { Text(stringResource(R.string.enable_notifications)) }
        if (Build.VERSION.SDK_INT >= 34) {
            Text(stringResource(if (fullScreenAllowed) R.string.permission_granted else R.string.permission_denied, stringResource(R.string.full_screen_permission)))
            Text(stringResource(R.string.full_screen_permission_hint), color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onFullScreenPermission, enabled = !fullScreenAllowed) { Text(stringResource(R.string.full_screen_permission)) }
        }
    }
}
