package com.alrart.app.domain

object MathAnswer {
    fun normalizeDigits(input: String): String = input
        .map { ch -> when (ch) {
            in '۰'..'۹' -> ('0'.code + ch.code - '۰'.code).toChar()
            in '٠'..'٩' -> ('0'.code + ch.code - '٠'.code).toChar()
            else -> ch
        } }.joinToString("").trim().replace("٫", ".")

    fun isCorrect(input: String, expected: Int): Boolean = normalizeDigits(input).toIntOrNull() == expected
}
