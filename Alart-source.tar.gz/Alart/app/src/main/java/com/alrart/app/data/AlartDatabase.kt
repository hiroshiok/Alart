package com.alrart.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [AlarmEntity::class, AlarmEventEntity::class], version = 5, exportSchema = true)
abstract class AlartDatabase : RoomDatabase() {
    abstract fun alarmDao(): AlarmDao
    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE alarms ADD COLUMN customMathQuestions TEXT NOT NULL DEFAULT ''")
            }
        }
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Rebuild once so SQLite defaults match Room's exported schema on both
                // databases upgraded from v2 and fresh installations of v3.
                database.execSQL("ALTER TABLE alarms RENAME TO alarms_v2")
                database.execSQL("""CREATE TABLE alarms (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    hour INTEGER NOT NULL,
                    minute INTEGER NOT NULL,
                    enabled INTEGER NOT NULL,
                    repeatDays TEXT NOT NULL,
                    title TEXT NOT NULL,
                    note TEXT NOT NULL,
                    color INTEGER NOT NULL,
                    soundUri TEXT,
                    vibration INTEGER NOT NULL,
                    mathEnabled INTEGER NOT NULL,
                    mathDifficulty TEXT NOT NULL,
                    mathQuestionCount INTEGER NOT NULL,
                    snoozeMinutes INTEGER NOT NULL,
                    nextTriggerAt INTEGER,
                    customMathQuestions TEXT NOT NULL DEFAULT '',
                    specificDate TEXT,
                    dateCalendar TEXT NOT NULL DEFAULT 'GREGORIAN'
                )""".trimIndent())
                database.execSQL("""INSERT INTO alarms (
                    id, hour, minute, enabled, repeatDays, title, note, color, soundUri,
                    vibration, mathEnabled, mathDifficulty, mathQuestionCount, snoozeMinutes,
                    nextTriggerAt, customMathQuestions
                ) SELECT id, hour, minute, enabled, repeatDays, title, note, color, soundUri,
                    vibration, mathEnabled, mathDifficulty, mathQuestionCount, snoozeMinutes,
                    nextTriggerAt, customMathQuestions FROM alarms_v2""".trimIndent())
                database.execSQL("DROP TABLE alarms_v2")
            }
        }
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE alarms ADD COLUMN soundVolume INTEGER NOT NULL DEFAULT 100")
            }
        }
        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE alarms ADD COLUMN challengeType TEXT NOT NULL DEFAULT 'MATH'")
                // Replace only the old application default; preserve colors users selected themselves.
                database.execSQL("UPDATE alarms SET color = 4294932992 WHERE color = 4284897491")
            }
        }
        @Volatile private var INSTANCE: AlartDatabase? = null
        fun get(context: Context): AlartDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AlartDatabase::class.java, "alart.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
                .build().also { INSTANCE = it }
        }
    }
}
