package com.alrart.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

private val Light = lightColorScheme(primary = Color(0xFF6658D3), secondary = Color(0xFF52617A), background = Color(0xFFF7F6FC), surface = Color(0xFFFFFFFF))
private val Dark = darkColorScheme(primary = Color(0xFFB9AEFF), secondary = Color(0xFFB8C6E0), background = Color(0xFF111118), surface = Color(0xFF1B1B25))

@Composable fun AlartTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    fontChoice: String = "sans",
    content: @Composable () -> Unit
) {
    val family = when (fontChoice) {
        "serif" -> FontFamily.Serif
        "mono" -> FontFamily.Monospace
        "cursive" -> FontFamily.Cursive
        else -> FontFamily.SansSerif
    }
    MaterialTheme(colorScheme = if (darkTheme) Dark else Light, typography = androidx.compose.material3.Typography(defaultFontFamily = family), content = content)
}
