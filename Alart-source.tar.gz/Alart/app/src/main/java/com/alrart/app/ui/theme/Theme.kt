package com.alrart.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import android.graphics.Typeface
import androidx.compose.ui.unit.sp

private val Light = lightColorScheme(
    primary = Color(0xFFEA531D), onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE1D2), onPrimaryContainer = Color(0xFF4A1708),
    secondary = Color(0xFFD99500), onSecondary = Color(0xFF241600),
    secondaryContainer = Color(0xFFFFE7A8), onSecondaryContainer = Color(0xFF3D2A00),
    tertiary = Color(0xFFD91E36), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFD9DE), onTertiaryContainer = Color(0xFF49000D),
    error = Color(0xFFBA1A1A), onError = Color.White,
    errorContainer = Color(0xFFFFDAD6), onErrorContainer = Color(0xFF410002),
    background = Color(0xFFFFF8F4), onBackground = Color(0xFF21110D),
    surface = Color(0xFFFFFDFC), onSurface = Color(0xFF21110D),
    surfaceVariant = Color(0xFFF4E6E0), onSurfaceVariant = Color(0xFF59443D),
    outline = Color(0xFF8D746B), outlineVariant = Color(0xFFE0C9BF),
    scrim = Color(0x660B0503)
)

private val Dark = darkColorScheme(
    primary = Color(0xFFFF884B), onPrimary = Color(0xFF401500),
    primaryContainer = Color(0xFF702B0B), onPrimaryContainer = Color(0xFFFFDBCB),
    secondary = Color(0xFFFFC247), onSecondary = Color(0xFF3A2600),
    secondaryContainer = Color(0xFF5A4000), onSecondaryContainer = Color(0xFFFFE2A0),
    tertiary = Color(0xFFFF6675), onTertiary = Color(0xFF5B0010),
    tertiaryContainer = Color(0xFF8D1528), onTertiaryContainer = Color(0xFFFFD9DE),
    error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A), onErrorContainer = Color(0xFFFFDAD6),
    background = Color(0xFF100907), onBackground = Color(0xFFFFF4EF),
    surface = Color(0xFF1C100D), onSurface = Color(0xFFFFF4EF),
    surfaceVariant = Color(0xFF30201A), onSurfaceVariant = Color(0xFFE1C2B4),
    outline = Color(0xFFAA8A7C), outlineVariant = Color(0xFF574038),
    scrim = Color(0x99000000)
)

@Composable
fun AlartTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    fontChoice: String = "sans",
    content: @Composable () -> Unit
) {
    val family = when (fontChoice) {
        "serif" -> FontFamily.Serif
        else -> FontFamily(Typeface.create("sans-serif-rounded", Typeface.NORMAL))
    }
    val base = Typography()
    val typography = base.copy(
        displayLarge = base.displayLarge.copy(fontFamily = family, fontWeight = FontWeight.Light, letterSpacing = (-1.2).sp, lineHeight = 62.sp),
        displayMedium = base.displayMedium.copy(fontFamily = family, fontWeight = FontWeight.Light, letterSpacing = (-0.7).sp),
        displaySmall = base.displaySmall.copy(fontFamily = family, fontWeight = FontWeight.Normal),
        headlineLarge = base.headlineLarge.copy(fontFamily = family, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.3).sp),
        headlineMedium = base.headlineMedium.copy(fontFamily = family, fontWeight = FontWeight.SemiBold),
        headlineSmall = base.headlineSmall.copy(fontFamily = family, fontWeight = FontWeight.SemiBold),
        titleLarge = base.titleLarge.copy(fontFamily = family, fontWeight = FontWeight.SemiBold),
        titleMedium = base.titleMedium.copy(fontFamily = family, fontWeight = FontWeight.Medium, lineHeight = 24.sp),
        titleSmall = base.titleSmall.copy(fontFamily = family, fontWeight = FontWeight.SemiBold),
        bodyLarge = base.bodyLarge.copy(fontFamily = family, fontWeight = FontWeight.Normal, lineHeight = 25.sp, letterSpacing = 0.05.sp),
        bodyMedium = base.bodyMedium.copy(fontFamily = family, fontWeight = FontWeight.Normal, lineHeight = 21.sp),
        bodySmall = base.bodySmall.copy(fontFamily = family, fontWeight = FontWeight.Normal, lineHeight = 18.sp),
        labelLarge = base.labelLarge.copy(fontFamily = family, fontWeight = FontWeight.SemiBold),
        labelMedium = base.labelMedium.copy(fontFamily = family, fontWeight = FontWeight.Medium),
        labelSmall = base.labelSmall.copy(fontFamily = family, fontWeight = FontWeight.Medium)
    )
    MaterialTheme(colorScheme = if (darkTheme) Dark else Light, typography = typography, content = content)
}
