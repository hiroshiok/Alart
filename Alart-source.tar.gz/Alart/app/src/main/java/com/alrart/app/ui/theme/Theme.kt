package com.alrart.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import android.graphics.Typeface
import androidx.compose.ui.unit.sp

/** High-contrast, quiet surfaces with a soft glass-inspired accent palette. */
private val Light = lightColorScheme(
    primary = Color(0xFF6250B5),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE8E1FF),
    onPrimaryContainer = Color(0xFF251B54),
    secondary = Color(0xFF287F79),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD1F1EB),
    onSecondaryContainer = Color(0xFF0A3935),
    tertiary = Color(0xFFB45D79),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFD9E4),
    onTertiaryContainer = Color(0xFF4B172B),
    error = Color(0xFFB3261E),
    onError = Color.White,
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    background = Color(0xFFF5F3F9),
    onBackground = Color(0xFF1D1B23),
    surface = Color(0xFFFFFEFF),
    onSurface = Color(0xFF1D1B23),
    surfaceVariant = Color(0xFFECE9F2),
    onSurfaceVariant = Color(0xFF484451),
    outline = Color(0xFF77717F),
    outlineVariant = Color(0xFFD2CEDA),
    scrim = Color(0x660B0814)
)

private val Dark = darkColorScheme(
    primary = Color(0xFFC9BDFF),
    onPrimary = Color(0xFF30245E),
    primaryContainer = Color(0xFF483B78),
    onPrimaryContainer = Color(0xFFF0EAFF),
    secondary = Color(0xFF91D8CE),
    onSecondary = Color(0xFF003731),
    secondaryContainer = Color(0xFF14534E),
    onSecondaryContainer = Color(0xFFBFEDE5),
    tertiary = Color(0xFFF3A9C0),
    onTertiary = Color(0xFF4A1830),
    tertiaryContainer = Color(0xFF6A354A),
    onTertiaryContainer = Color(0xFFFFD9E5),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    background = Color(0xFF101116),
    onBackground = Color(0xFFF2EFF8),
    surface = Color(0xFF20222B),
    onSurface = Color(0xFFF8F6FE),
    surfaceVariant = Color(0xFF30323D),
    onSurfaceVariant = Color(0xFFD0CCDA),
    outline = Color(0xFFAAA4B5),
    outlineVariant = Color(0xFF555664),
    scrim = Color(0x99000000)
)

@Composable
fun AlartTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    fontChoice: String = "sans",
    content: @Composable () -> Unit
) {
    val family = when (fontChoice) {
        "serif" -> FontFamily.Serif
        else -> FontFamily(Typeface.create("sans-serif-rounded", Typeface.NORMAL))
    }
    val base = Typography()
    val typography = base.copy(
        displayLarge = base.displayLarge.copy(fontFamily = family, fontWeight = FontWeight.Light, letterSpacing = (-1.2).sp, lineHeight = 62.sp),
        displayMedium = base.displayMedium.copy(fontFamily = family, fontWeight = FontWeight.Light, letterSpacing = (-0.7).sp),
        displaySmall = base.displaySmall.copy(fontFamily = family, fontWeight = FontWeight.Normal),
        headlineLarge = base.headlineLarge.copy(fontFamily = family, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.3).sp),
        headlineMedium = base.headlineMedium.copy(fontFamily = family, fontWeight = FontWeight.SemiBold),
        headlineSmall = base.headlineSmall.copy(fontFamily = family, fontWeight = FontWeight.SemiBold),
        titleLarge = base.titleLarge.copy(fontFamily = family, fontWeight = FontWeight.SemiBold),
        titleMedium = base.titleMedium.copy(fontFamily = family, fontWeight = FontWeight.Medium, lineHeight = 24.sp),
        titleSmall = base.titleSmall.copy(fontFamily = family, fontWeight = FontWeight.SemiBold),
        bodyLarge = base.bodyLarge.copy(fontFamily = family, fontWeight = FontWeight.Normal, lineHeight = 25.sp, letterSpacing = 0.05.sp),
        bodyMedium = base.bodyMedium.copy(fontFamily = family, fontWeight = FontWeight.Normal, lineHeight = 21.sp),
        bodySmall = base.bodySmall.copy(fontFamily = family, fontWeight = FontWeight.Normal, lineHeight = 18.sp),
        labelLarge = base.labelLarge.copy(fontFamily = family, fontWeight = FontWeight.SemiBold),
        labelMedium = base.labelMedium.copy(fontFamily = family, fontWeight = FontWeight.Medium),
        labelSmall = base.labelSmall.copy(fontFamily = family, fontWeight = FontWeight.Medium)
    )
    MaterialTheme(colorScheme = if (darkTheme) Dark else Light, typography = typography, content = content)
}
