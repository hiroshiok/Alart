package com.alrart.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

// A brighter, layered palette designed for translucent "liquid glass" surfaces.
private val Light = lightColorScheme(
    primary = Color(0xFF6554E8),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF7669F5),
    onPrimaryContainer = Color.White,
    secondary = Color(0xFF008F87),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFB9F2E9),
    onSecondaryContainer = Color(0xFF073F3B),
    tertiary = Color(0xFFFF7D68),
    tertiaryContainer = Color(0xFFFFD8CE),
    background = Color(0xFFF2F1FF),
    surface = Color(0xFFFCFBFF),
    surfaceVariant = Color(0xFFE5E4F7),
    outlineVariant = Color(0xFFBDBBDA)
)
private val Dark = darkColorScheme(
    primary = Color(0xFFB8AEFF),
    onPrimary = Color(0xFF21165F),
    primaryContainer = Color(0xFF5142B5),
    onPrimaryContainer = Color(0xFFF7F4FF),
    secondary = Color(0xFF70DED1),
    onSecondary = Color(0xFF003731),
    secondaryContainer = Color(0xFF145B54),
    onSecondaryContainer = Color(0xFFC5FFF5),
    tertiary = Color(0xFFFFA18F),
    tertiaryContainer = Color(0xFF713B37),
    background = Color(0xFF11121E),
    surface = Color(0xFF1C1D2B),
    surfaceVariant = Color(0xFF292A3C),
    outlineVariant = Color(0xFF45465C)
)

@Composable
fun AlartTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    fontChoice: String = "sans",
    content: @Composable () -> Unit
) {
    val family = when (fontChoice) {
        "serif" -> FontFamily.Serif
        "mono" -> FontFamily.Monospace
        "cursive" -> FontFamily.Cursive
        else -> FontFamily.SansSerif
    }
    val base = androidx.compose.material3.Typography()
    val typography = base.copy(
        displayLarge = base.displayLarge.copy(fontFamily = family),
        displayMedium = base.displayMedium.copy(fontFamily = family),
        displaySmall = base.displaySmall.copy(fontFamily = family),
        headlineLarge = base.headlineLarge.copy(fontFamily = family),
        headlineMedium = base.headlineMedium.copy(fontFamily = family),
        headlineSmall = base.headlineSmall.copy(fontFamily = family),
        titleLarge = base.titleLarge.copy(fontFamily = family),
        titleMedium = base.titleMedium.copy(fontFamily = family),
        titleSmall = base.titleSmall.copy(fontFamily = family),
        bodyLarge = base.bodyLarge.copy(fontFamily = family),
        bodyMedium = base.bodyMedium.copy(fontFamily = family),
        bodySmall = base.bodySmall.copy(fontFamily = family),
        labelLarge = base.labelLarge.copy(fontFamily = family),
        labelMedium = base.labelMedium.copy(fontFamily = family),
        labelSmall = base.labelSmall.copy(fontFamily = family)
    )
    MaterialTheme(colorScheme = if (darkTheme) Dark else Light, typography = typography, content = content)
}
