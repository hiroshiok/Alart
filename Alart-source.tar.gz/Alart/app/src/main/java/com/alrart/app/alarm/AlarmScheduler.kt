package com.alrart.app.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.alrart.app.data.AlarmEntity
import com.alrart.app.domain.AlarmTime
import java.time.LocalDateTime

class AlarmScheduler(private val context: Context) {
    private val manager = context.getSystemService(AlarmManager::class.java)

    fun canScheduleExact(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || manager.canScheduleExactAlarms()

    /** Schedules an alarm and returns its persisted wall-clock trigger, or null on failure. */
    fun schedule(alarm: AlarmEntity): Long? {
        if (!alarm.enabled) { cancel(alarm.id); return 0L }
        val trigger = AlarmTime.nextOccurrence(alarm, LocalDateTime.now()) ?: run { cancel(alarm.id); return null }
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra(AlarmReceiver.EXTRA_ALARM_ID, alarm.id)
            putExtra(AlarmReceiver.EXTRA_EXPECTED_TRIGGER, trigger)
            putExtra(AlarmReceiver.EXTRA_SOUND_URI, alarm.soundUri)
            putExtra(AlarmReceiver.EXTRA_VIBRATION, alarm.vibration)
            putExtra(AlarmReceiver.EXTRA_SOUND_VOLUME, alarm.soundVolume)
            putExtra(AlarmReceiver.EXTRA_ALARM_TITLE, alarm.title)
        }
        val pending = PendingIntent.getBroadcast(context, alarm.id.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return try {
            if (canScheduleExact()) {
                val showIntent = PendingIntent.getActivity(context, 0,
                    Intent(context, com.alrart.app.MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                manager.setAlarmClock(AlarmManager.AlarmClockInfo(trigger, showIntent), pending)
            } else {
                // Keep alarms functional even when Android has not granted exact-alarm
                // access. The OS may delay this fallback, but it must not silently drop it.
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
            }
            trigger
        } catch (_: SecurityException) {
            runCatching {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
                trigger
            }.getOrNull()
        } catch (_: RuntimeException) { null }
    }

    fun cancel(id: Long) {
        val intent = Intent(context, AlarmReceiver::class.java).putExtra(AlarmReceiver.EXTRA_ALARM_ID, id)
        val pending = PendingIntent.getBroadcast(context, id.toInt(), intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
        if (pending != null) manager.cancel(pending)
    }

    suspend fun rescheduleAll() {
        val dao = com.alrart.app.data.AlartDatabase.get(context).alarmDao()
        dao.enabled().forEach { alarm ->
            val next = schedule(alarm)
            dao.setNextTrigger(alarm.id, next)
        }
    }
}
