package com.alrart.app.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import com.alrart.app.data.AlarmEntity
import com.alrart.app.data.AlartDatabase
import com.alrart.app.domain.AlarmTime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDateTime

/** Owns one stable PendingIntent per saved alarm and only reports success for exact schedules. */
class AlarmScheduler(private val context: Context) {
    private val manager = context.getSystemService(AlarmManager::class.java)

    fun canScheduleExact(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S || manager.canScheduleExactAlarms()

    fun schedule(alarm: AlarmEntity): Long? {
        if (!alarm.enabled) {
            cancel(alarm.id)
            return 0L
        }
        val exactAllowed = canScheduleExact()
        // Recompute when an alarm is edited; never reuse a cached trigger from its old time.
        val trigger = AlarmTime.nextOccurrence(alarm.copy(nextTriggerAt = null), LocalDateTime.now())
            ?: run {
                cancel(alarm.id)
                AlarmDiagnostics.record(context, "SCHEDULE_INVALID", "No future occurrence for alarm ${alarm.id}")
                return null
            }

        val pending = alarmPendingIntent(alarm.id, alarm, trigger)
        return try {
            val showIntent = PendingIntent.getActivity(
                context,
                0,
                Intent(context, com.alrart.app.MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            if (exactAllowed) {
                manager.setAlarmClock(AlarmManager.AlarmClockInfo(trigger, showIntent), pending)
                AlarmDiagnostics.record(context, "SCHEDULED_EXACT", "id=${alarm.id}; trigger=$trigger")
            } else {
                // Do not silently leave an enabled alarm unscheduled. Android may defer
                // this idle-safe inexact fallback, but it is better than no alarm at all.
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
                AlarmDiagnostics.record(context, "SCHEDULED_APPROXIMATE", "id=${alarm.id}; trigger=$trigger; exact access unavailable")
            }
            trigger
        } catch (error: SecurityException) {
            AlarmDiagnostics.record(context, "SCHEDULE_FAILED", "SecurityException: ${error.message}")
            null
        } catch (error: RuntimeException) {
            AlarmDiagnostics.record(context, "SCHEDULE_FAILED", "${error.javaClass.simpleName}: ${error.message}")
            null
        }
    }

    fun cancel(id: Long) {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_TRIGGER
            data = Uri.parse("alart://alarm/$id")
        }
        val pending = PendingIntent.getBroadcast(
            context,
            id.toInt(),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pending != null) manager.cancel(pending)
    }

    private fun alarmPendingIntent(id: Long, alarm: AlarmEntity, expectedTrigger: Long): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_TRIGGER
            data = Uri.parse("alart://alarm/$id")
            putExtra(AlarmReceiver.EXTRA_ALARM_ID, id)
            putExtra(AlarmReceiver.EXTRA_EXPECTED_TRIGGER, expectedTrigger)
            putExtra(AlarmReceiver.EXTRA_SOUND_URI, alarm.soundUri)
            putExtra(AlarmReceiver.EXTRA_VIBRATION, alarm.vibration)
            putExtra(AlarmReceiver.EXTRA_SOUND_VOLUME, alarm.soundVolume)
            putExtra(AlarmReceiver.EXTRA_ALARM_TITLE, alarm.title)
        }
        // Stable identity includes alarm id, while this payload contains the exact same
        // timestamp that is persisted in Room after setAlarmClock succeeds.
        return PendingIntent.getBroadcast(
            context,
            id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    suspend fun rescheduleAll() = withContext(Dispatchers.IO) {
        val dao = AlartDatabase.get(context).alarmDao()
        if (!canScheduleExact()) {
            AlarmDiagnostics.record(context, "RESCHEDULE_APPROXIMATE", "Exact-alarm access is not granted; fallback schedules will be used")
        }
        dao.enabled().forEach { alarm ->
            val next = schedule(alarm)
            dao.setNextTrigger(alarm.id, next)
        }
    }
}
