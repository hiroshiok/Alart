package com.alrart.app.domain

import com.alrart.app.data.AlarmEventEntity

data class AlarmStatistics(val setCount: Int, val ringCount: Int, val snoozeCount: Int, val averageDismissMillis: Long?)
object Statistics {
    fun from(events: List<AlarmEventEntity>): AlarmStatistics {
        val sets = events.count { it.eventType == "SET" }
        val rings = events.filter { it.eventType == "RING" }
        val snoozes = events.count { it.eventType == "SNOOZE" }
        // Only completed ring sessions contribute to the average. A snooze closes a
        // session too; a ring that is still active is intentionally excluded.
        val durations = rings.mapNotNull { event ->
            event.dismissedAt?.minus(event.occurredAt)?.takeIf { it >= 0L }
        }
        return AlarmStatistics(
            setCount = sets,
            ringCount = rings.size,
            snoozeCount = snoozes,
            averageDismissMillis = durations.takeIf { it.isNotEmpty() }?.average()?.toLong()
        )
    }
}
