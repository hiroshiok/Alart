package com.alrart.app.domain

import java.time.LocalDate

/** Persian (Solar Hijri) calendar conversion using the 33-year break-point algorithm. */
data class JalaliDate(val year: Int, val month: Int, val day: Int) {
    init {
        require(month in 1..12) { "month must be 1..12" }
        require(day in 1..31) { "day must be 1..31" }
    }

    fun toGregorian(): LocalDate {
        val info = jalCal(year)
        val yearStart = LocalDate.of(info.gregorianYear, 3, info.marchDay)
        val dayOfYear = when {
            month <= 6 -> (month - 1) * 31 + day - 1
            month <= 11 -> 186 + (month - 7) * 30 + day - 1
            else -> 336 + day - 1
        }
        val result = yearStart.plusDays(dayOfYear.toLong())
        require(fromGregorian(result).year == year && fromGregorian(result).month == month && fromGregorian(result).day == day) {
            "Invalid Solar Hijri date"
        }
        return result
    }

    fun toIsoString(): String = toGregorian().toString()

    companion object {
        private val breaks = intArrayOf(-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178)
        private data class CalendarInfo(val gregorianYear: Int, val marchDay: Int)

        private fun div(a: Int, b: Int) = a / b
        private fun mod(a: Int, b: Int) = a - div(a, b) * b

        private fun jalCal(jy: Int): CalendarInfo {
            require(jy >= breaks.first() && jy < breaks.last()) { "Solar Hijri year out of supported range" }
            val gy = jy + 621
            var leapJ = -14
            var jp = breaks[0]
            var jump = 0
            for (i in 1 until breaks.size) {
                val jm = breaks[i]
                jump = jm - jp
                if (jy < jm) break
                leapJ += div(jump, 33) * 8 + div(mod(jump, 33), 4)
                jp = jm
            }
            var n = jy - jp
            leapJ += div(n, 33) * 8 + div(mod(n, 33) + 3, 4)
            if (mod(jump, 33) == 4 && jump - n == 4) leapJ++
            val leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150
            return CalendarInfo(gy, 20 + leapJ - leapG)
        }

        fun fromGregorian(date: LocalDate): JalaliDate {
            var jy = date.year - 621
            var info = jalCal(jy)
            var start = LocalDate.of(info.gregorianYear, 3, info.marchDay)
            if (date.isBefore(start)) {
                jy--
                info = jalCal(jy)
                start = LocalDate.of(info.gregorianYear, 3, info.marchDay)
            }
            val dayOfYear = (date.toEpochDay() - start.toEpochDay()).toInt()
            val (month, day) = when {
                dayOfYear < 186 -> (dayOfYear / 31 + 1) to (dayOfYear % 31 + 1)
                dayOfYear < 336 -> ((dayOfYear - 186) / 30 + 7) to ((dayOfYear - 186) % 30 + 1)
                else -> 12 to (dayOfYear - 336 + 1)
            }
            return JalaliDate(jy, month, day)
        }

        fun parse(value: String): JalaliDate? {
            val parts = value.trim().replace('-', '/').split('/')
            if (parts.size != 3) return null
            val numbers = parts.map { MathAnswer.normalizeDigits(it).toIntOrNull() ?: return null }
            return runCatching { JalaliDate(numbers[0], numbers[1], numbers[2]).also { it.toGregorian() } }.getOrNull()
        }
    }
}
