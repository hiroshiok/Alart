package com.alrart.app.alarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import androidx.core.app.NotificationCompat
import com.alrart.app.R

/** Owns alarm playback independently of the lock-screen Activity lifecycle. */
class AlarmSoundService : Service() {
    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var currentAlarmId: Long = -1L
    private var generation = 0
    private var fallbackRingtone: Ringtone? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var testStopRunnable: Runnable? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val startIntent = intent
        if (startIntent?.action == ACTION_STOP) {
            stopPlayback()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        if (startIntent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        currentAlarmId = startIntent.getLongExtra(AlarmReceiver.EXTRA_ALARM_ID, -1L)
        if (currentAlarmId < 0L) {
            stopSelf()
            return START_NOT_STICKY
        }

        ensureChannel()
        val notification = buildForegroundNotification(
            startIntent.getStringExtra(AlarmReceiver.EXTRA_ALARM_TITLE).orEmpty()
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(FOREGROUND_NOTIFICATION_ID, notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(FOREGROUND_NOTIFICATION_ID, notification)
            }
            AlarmDiagnostics.record(this, "FOREGROUND_SERVICE_STARTED", "id=$currentAlarmId")
        } catch (error: Exception) {
            AlarmDiagnostics.record(this, "FOREGROUND_SERVICE_FAILED", "${error.javaClass.simpleName}: ${error.message}")
            stopSelf(startId)
            return START_NOT_STICKY
        }
        try {
            startPlayback(
                startIntent.getStringExtra(AlarmReceiver.EXTRA_SOUND_URI),
                startIntent.getIntExtra(AlarmReceiver.EXTRA_SOUND_VOLUME, 100).coerceIn(0, 100),
                startIntent.getBooleanExtra(AlarmReceiver.EXTRA_VIBRATION, true)
            )
        } catch (_: Exception) {
            clearPlaybackState()
            stopSelf(startId)
            return START_NOT_STICKY
        }
        if (startIntent.getBooleanExtra(EXTRA_TEST_MODE, false)) {
            testStopRunnable?.let(mainHandler::removeCallbacks)
            testStopRunnable = Runnable {
                stopPlayback()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                AlarmDiagnostics.record(this, "TEST_PLAYBACK_FINISHED", "Automatic 12-second test stop")
            }.also { mainHandler.postDelayed(it, 12_000L) }
        }
        return START_NOT_STICKY
    }

    private fun startPlayback(sound: String?, volume: Int, vibrate: Boolean) {
        stopPlayback()
        getSharedPreferences("alart_audio_state", MODE_PRIVATE).edit()
            .putLong("starting_alarm_id", currentAlarmId)
            .remove("playing_alarm_id")
            .putLong("starting_at", System.currentTimeMillis())
            .apply()
        val request = ++generation
        val candidates = listOfNotNull(
            sound?.let { runCatching { Uri.parse(it) }.getOrNull() },
            Settings.System.DEFAULT_ALARM_ALERT_URI,
            Settings.System.DEFAULT_NOTIFICATION_URI
        ).distinct()
        playCandidate(candidates, 0, request, volume)
        if (vibrate) {
            vibrator = getSystemService(Vibrator::class.java)
            val pattern = longArrayOf(0, 650, 350)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        }
    }

    private fun playCandidate(candidates: List<Uri>, index: Int, request: Int, volume: Int) {
        if (request != generation) return
        if (index >= candidates.size) { playFallbackRingtone(request); return }
        val player = MediaPlayer()
        try {
            player.setWakeMode(this, android.os.PowerManager.PARTIAL_WAKE_LOCK)
            player.setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build())
            player.isLooping = true
            val level = volume / 100f
            player.setVolume(level, level)
            player.setDataSource(this, candidates[index])
            player.setOnPreparedListener { prepared ->
                if (request == generation) {
                    runCatching {
                        prepared.start()
                        getSharedPreferences("alart_audio_state", MODE_PRIVATE).edit()
                            .putLong("playing_alarm_id", currentAlarmId)
                            .remove("starting_alarm_id")
                            .remove("starting_at")
                            .apply()
                        AlarmDiagnostics.record(this, "AUDIO_PLAYBACK_STARTED", "MediaPlayer prepared for id=$currentAlarmId")
                    }.onFailure {
                        runCatching { prepared.release() }
                        playCandidate(candidates, index + 1, request, volume)
                    }
                } else prepared.release()
            }
            player.setOnErrorListener { failed, what, extra ->
                runCatching { failed.release() }
                AlarmDiagnostics.record(this, "MEDIA_PLAYER_ERROR", "what=$what; extra=$extra; uri=${candidates[index]}")
                if (request == generation) {
                    if (index + 1 < candidates.size) playCandidate(candidates, index + 1, request, volume)
                    else playFallbackRingtone(request)
                }
                true
            }
            mediaPlayer = player
            player.prepareAsync()
        } catch (error: Exception) {
            runCatching { player.release() }
            AlarmDiagnostics.record(this, "MEDIA_PLAYER_SETUP_ERROR", "${error.javaClass.simpleName}: ${error.message}")
            if (index + 1 < candidates.size) playCandidate(candidates, index + 1, request, volume)
            else playFallbackRingtone(request)
        }
    }

    private fun playFallbackRingtone(request: Int) {
        if (request != generation) return
        val candidates = listOfNotNull(Settings.System.DEFAULT_ALARM_ALERT_URI, Settings.System.DEFAULT_NOTIFICATION_URI).distinct()
        for (uri in candidates) {
            val tone = runCatching { RingtoneManager.getRingtone(this, uri) }.getOrNull() ?: continue
            val started = runCatching {
                tone.audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) tone.isLooping = true
                tone.play()
                tone.isPlaying
            }.getOrDefault(false)
            if (started) {
                fallbackRingtone = tone
                getSharedPreferences("alart_audio_state", MODE_PRIVATE).edit()
                    .putLong("playing_alarm_id", currentAlarmId)
                    .remove("starting_alarm_id")
                    .remove("starting_at")
                    .apply()
                AlarmDiagnostics.record(this, "AUDIO_FALLBACK_STARTED", "RingtoneManager fallback for id=$currentAlarmId")
                return
            }
            runCatching { tone.stop() }
        }
        clearPlaybackState()
        AlarmDiagnostics.record(this, "AUDIO_PLAYBACK_FAILED", "All MediaPlayer and RingtoneManager sources failed")
    }

    private fun clearPlaybackState() {
        getSharedPreferences("alart_audio_state", MODE_PRIVATE).edit()
            .remove("playing_alarm_id")
            .remove("starting_alarm_id")
            .remove("starting_at")
            .apply()
    }

    private fun stopPlayback() {
        generation++
        testStopRunnable?.let(mainHandler::removeCallbacks)
        testStopRunnable = null
        clearPlaybackState()
        runCatching { mediaPlayer?.stop() }
        runCatching { mediaPlayer?.release() }
        mediaPlayer = null
        runCatching { fallbackRingtone?.stop() }
        fallbackRingtone = null
        vibrator?.cancel()
        vibrator = null
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(
                CHANNEL_ID, getString(R.string.alarm_playback_channel), NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.alarm_playback_channel_description)
                setSound(null, null)
                enableVibration(false)
            })
        }
    }

    private fun buildForegroundNotification(title: String): Notification {
        val open = PendingIntent.getActivity(this, 0,
            Intent(this, com.alrart.app.ui.RingingActivity::class.java)
                .putExtra(AlarmReceiver.EXTRA_ALARM_ID, currentAlarmId),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title.ifBlank { getString(R.string.app_name) })
            .setContentText(getString(R.string.alarm_is_ringing))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    override fun onDestroy() {
        stopPlayback()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.alrart.app.alarm.START_SOUND"
        const val ACTION_STOP = "com.alrart.app.alarm.STOP_SOUND"
        const val EXTRA_TEST_MODE = "test_mode"
        const val CHANNEL_ID = "alart_playback_service_v1"
        const val FOREGROUND_NOTIFICATION_ID = 91001
    }
}
