package com.alrart.app.alarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import androidx.core.app.NotificationCompat
import com.alrart.app.R

/** Owns alarm playback independently of the lock-screen Activity lifecycle. */
class AlarmSoundService : Service() {
    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var currentAlarmId: Long = -1L
    private var generation = 0

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val startIntent = intent
        if (startIntent?.action == ACTION_STOP) {
            stopPlayback()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        if (startIntent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        currentAlarmId = startIntent.getLongExtra(AlarmReceiver.EXTRA_ALARM_ID, -1L)
        if (currentAlarmId < 0L) {
            stopSelf()
            return START_NOT_STICKY
        }

        ensureChannel()
        val notification = buildForegroundNotification(
            startIntent.getStringExtra(AlarmReceiver.EXTRA_ALARM_TITLE).orEmpty()
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(FOREGROUND_NOTIFICATION_ID, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(FOREGROUND_NOTIFICATION_ID, notification)
        }
        try {
            startPlayback(
                startIntent.getStringExtra(AlarmReceiver.EXTRA_SOUND_URI),
                startIntent.getIntExtra(AlarmReceiver.EXTRA_SOUND_VOLUME, 100).coerceIn(0, 100),
                startIntent.getBooleanExtra(AlarmReceiver.EXTRA_VIBRATION, true)
            )
        } catch (_: Exception) {
            clearPlaybackState()
            stopSelf(startId)
            return START_NOT_STICKY
        }
        return START_NOT_STICKY
    }

    private fun startPlayback(sound: String?, volume: Int, vibrate: Boolean) {
        stopPlayback()
        getSharedPreferences("alart_audio_state", MODE_PRIVATE).edit()
            .putLong("starting_alarm_id", currentAlarmId)
            .remove("playing_alarm_id")
            .putLong("starting_at", System.currentTimeMillis())
            .apply()
        val request = ++generation
        val candidates = listOfNotNull(
            sound?.let { runCatching { Uri.parse(it) }.getOrNull() },
            Settings.System.DEFAULT_ALARM_ALERT_URI,
            Settings.System.DEFAULT_NOTIFICATION_URI
        ).distinct()
        playCandidate(candidates, 0, request, volume)
        if (vibrate) {
            vibrator = getSystemService(Vibrator::class.java)
            val pattern = longArrayOf(0, 650, 350)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        }
    }

    private fun playCandidate(candidates: List<Uri>, index: Int, request: Int, volume: Int) {
        if (request != generation) return
        if (index >= candidates.size) { clearPlaybackState(); return }
        val player = MediaPlayer()
        try {
            player.setWakeMode(this, android.os.PowerManager.PARTIAL_WAKE_LOCK)
            player.setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build())
            player.isLooping = true
            val level = volume / 100f
            player.setVolume(level, level)
            player.setDataSource(this, candidates[index])
            player.setOnPreparedListener { prepared ->
                if (request == generation) {
                    runCatching {
                        prepared.start()
                        getSharedPreferences("alart_audio_state", MODE_PRIVATE).edit()
                            .putLong("playing_alarm_id", currentAlarmId)
                            .remove("starting_alarm_id")
                            .remove("starting_at")
                            .apply()
                    }.onFailure {
                        runCatching { prepared.release() }
                        playCandidate(candidates, index + 1, request, volume)
                    }
                } else prepared.release()
            }
            player.setOnErrorListener { failed, _, _ ->
                runCatching { failed.release() }
                if (request == generation) playCandidate(candidates, index + 1, request, volume)
                true
            }
            mediaPlayer = player
            player.prepareAsync()
        } catch (_: Exception) {
            runCatching { player.release() }
            playCandidate(candidates, index + 1, request, volume)
        }
    }

    private fun clearPlaybackState() {
        getSharedPreferences("alart_audio_state", MODE_PRIVATE).edit()
            .remove("playing_alarm_id")
            .remove("starting_alarm_id")
            .remove("starting_at")
            .apply()
    }

    private fun stopPlayback() {
        generation++
        clearPlaybackState()
        runCatching { mediaPlayer?.stop() }
        runCatching { mediaPlayer?.release() }
        mediaPlayer = null
        vibrator?.cancel()
        vibrator = null
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(
                CHANNEL_ID, getString(R.string.alarm_playback_channel), NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.alarm_playback_channel_description)
                setSound(null, null)
                enableVibration(false)
            })
        }
    }

    private fun buildForegroundNotification(title: String): Notification {
        val open = PendingIntent.getActivity(this, 0,
            Intent(this, com.alrart.app.ui.RingingActivity::class.java)
                .putExtra(AlarmReceiver.EXTRA_ALARM_ID, currentAlarmId),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title.ifBlank { getString(R.string.app_name) })
            .setContentText(getString(R.string.alarm_is_ringing))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    override fun onDestroy() {
        stopPlayback()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.alrart.app.alarm.START_SOUND"
        const val ACTION_STOP = "com.alrart.app.alarm.STOP_SOUND"
        const val CHANNEL_ID = "alart_playback_service_v1"
        const val FOREGROUND_NOTIFICATION_ID = 91001
    }
}
