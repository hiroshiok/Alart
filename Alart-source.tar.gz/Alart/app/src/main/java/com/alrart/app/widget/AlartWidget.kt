package com.alrart.app.widget

import android.content.Context
import android.content.Intent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceModifier
import androidx.glance.ExperimentalGlanceApi
import androidx.glance.LocalSize
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.alrart.app.MainActivity
import com.alrart.app.data.AlartDatabase
import com.alrart.app.domain.AlarmTime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.Duration
import java.time.Instant
import java.time.LocalDateTime
import java.util.Locale

/** Responsive, high-contrast glass-inspired home-screen alarm surface. */
class AlartWidget : GlanceAppWidget() {
    override val sizeMode = SizeMode.Responsive(
        setOf(DpSize(180.dp, 100.dp), DpSize(250.dp, 150.dp), DpSize(320.dp, 190.dp))
    )

    @OptIn(ExperimentalGlanceApi::class)
    override suspend fun provideGlance(context: Context, id: androidx.glance.GlanceId) {
        val upcoming = withContext(Dispatchers.IO) {
            val now = LocalDateTime.now()
            AlartDatabase.get(context).alarmDao().enabled()
                .mapNotNull { alarm -> AlarmTime.nextOccurrence(alarm, now)?.let { alarm to it } }
                .sortedBy { it.second }
                .take(3)
        }
        val noAlarm = context.getString(com.alrart.app.R.string.widget_no_alarm)
        val nextLabel = context.getString(com.alrart.app.R.string.widget_next_alarm)
        val launchIntent = Intent(context, MainActivity::class.java)
        provideContent {
            val size = LocalSize.current
            val expanded = size.width >= 250.dp && size.height >= 145.dp
            val first = upcoming.firstOrNull()
            val remaining = first?.second?.let { trigger ->
                val minutes = Duration.between(Instant.now(), Instant.ofEpochMilli(trigger)).toMinutes().coerceAtLeast(0)
                val hours = minutes / 60
                val mins = minutes % 60
                if (hours > 0) String.format(Locale.getDefault(), "%d:%02d", hours, mins)
                else context.getString(com.alrart.app.R.string.time_left, "$mins ${context.getString(com.alrart.app.R.string.minutes)}")
            }
            val background = ColorProvider(Color(0xFF29283A))
            val foreground = ColorProvider(Color(0xFFFFFCFF))
            val secondary = ColorProvider(Color(0xFFD8D3E3))
            val accent = ColorProvider(Color(0xFFD2C4FF))
            val panel = ColorProvider(Color(0xFF403B53))

            Column(
                modifier = GlanceModifier.fillMaxSize()
                    .background(background)
                    .cornerRadius(30.dp)
                    .padding(if (expanded) 18.dp else 14.dp)
                    .clickable(actionStartActivity(launchIntent)),
                verticalAlignment = Alignment.Vertical.CenterVertically,
                horizontalAlignment = Alignment.Horizontal.Start
            ) {
                Row(modifier = GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.Vertical.CenterVertically) {
                    Text(
                        "ALART",
                        style = TextStyle(color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    )
                    Spacer(GlanceModifier.width(10.dp))
                    Text(
                        nextLabel.uppercase(),
                        style = TextStyle(color = secondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    )
                }
                Spacer(GlanceModifier.height(5.dp))
                Row(modifier = GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.Vertical.Bottom) {
                    Text(
                        first?.let { String.format(Locale.getDefault(), "%02d:%02d", it.first.hour, it.first.minute) } ?: "--:--",
                        style = TextStyle(color = foreground, fontSize = if (expanded) 40.sp else 33.sp, fontWeight = FontWeight.Medium)
                    )
                    Spacer(GlanceModifier.width(10.dp))
                    if (remaining != null) {
                        Text(remaining, style = TextStyle(color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold))
                    }
                }
                Text(
                    first?.first?.title?.ifBlank { noAlarm } ?: noAlarm,
                    style = TextStyle(color = secondary, fontSize = 11.sp, fontWeight = FontWeight.Medium),
                    maxLines = 1
                )
                if (expanded) {
                    Spacer(GlanceModifier.height(10.dp))
                    Row(
                        modifier = GlanceModifier.fillMaxWidth()
                            .background(panel)
                            .cornerRadius(18.dp)
                            .padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.Vertical.CenterVertically
                    ) {
                        upcoming.drop(1).take(2).forEachIndexed { index, entry ->
                            Column(modifier = GlanceModifier.width(104.dp)) {
                                Text(
                                    String.format(Locale.getDefault(), "%02d:%02d", entry.first.hour, entry.first.minute),
                                    style = TextStyle(color = accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    entry.first.title.ifBlank { nextLabel },
                                    style = TextStyle(color = secondary, fontSize = 9.sp),
                                    maxLines = 1
                                )
                            }
                            if (index == 0 && upcoming.size > 2) Spacer(GlanceModifier.width(12.dp))
                        }
                        if (upcoming.size <= 1) {
                            Text(context.getString(com.alrart.app.R.string.widget_open_app), style = TextStyle(color = secondary, fontSize = 10.sp))
                        }
                    }
                }
            }
        }
    }
}

class AlartWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = AlartWidget()
}
