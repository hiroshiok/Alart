package com.alrart.app.widget

import android.content.Context
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.LocalSize
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import androidx.glance.unit.sp
import com.alrart.app.MainActivity
import com.alrart.app.data.AlarmEntity
import com.alrart.app.data.AlartDatabase
import com.alrart.app.domain.AlarmTime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDateTime

class AlartWidget : GlanceAppWidget() {
    override val sizeMode = SizeMode.Responsive(
        setOf(DpSize(180.dp, 100.dp), DpSize(250.dp, 150.dp), DpSize(320.dp, 190.dp))
    )

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val upcoming = withContext(Dispatchers.IO) {
            AlartDatabase.get(context).alarmDao().enabled().mapNotNull { alarm ->
                AlarmTime.nextOccurrence(alarm, LocalDateTime.now())?.let { alarm to it }
            }.sortedBy { it.second }.take(3).map { it.first }
        }
        val nextAlarm = upcoming.firstOrNull()
        val title = context.getString(com.alrart.app.R.string.app_name)
        val noAlarm = context.getString(com.alrart.app.R.string.widget_no_alarm)
        val nextLabel = context.getString(com.alrart.app.R.string.widget_next_alarm)
        provideContent {
            val size = LocalSize.current
            Column(
                modifier = GlanceModifier.fillMaxSize()
                    .background(ColorProvider(Color(0xFF171923)))
                    .padding(16.dp)
                    .clickable(actionStartActivity<MainActivity>()),
                verticalAlignment = Alignment.Vertical.CenterVertically,
                horizontalAlignment = Alignment.Horizontal.Start
            ) {
                Text(title.uppercase(), style = TextStyle(color = ColorProvider(Color(0xFFB9AEFF)), fontSize = 13.sp, fontWeight = FontWeight.Bold))
                Spacer(GlanceModifier.height(6.dp))
                Text(
                    nextAlarm?.let { "%02d:%02d".format(it.hour, it.minute) } ?: "--:--",
                    style = TextStyle(color = ColorProvider(Color.White), fontSize = if (size.height < 120.dp) 26.sp else 32.sp, fontWeight = FontWeight.Medium)
                )
                Text(
                    nextAlarm?.title?.ifBlank { nextLabel } ?: noAlarm,
                    style = TextStyle(color = ColorProvider(Color(0xFFCACAD2)), fontSize = 12.sp)
                )
                if (size.height >= 150.dp && upcoming.size > 1) {
                    Spacer(GlanceModifier.height(8.dp))
                    upcoming.drop(1).forEach { alarm ->
                        Row {
                            Text("•  %02d:%02d".format(alarm.hour, alarm.minute), style = TextStyle(color = ColorProvider(Color(0xFFB9AEFF)), fontSize = 11.sp))
                            Spacer(GlanceModifier.width(4.dp))
                            Text("  ${alarm.title.ifBlank { nextLabel }}", style = TextStyle(color = ColorProvider(Color(0xFFCACAD2)), fontSize = 11.sp))
                        }
                    }
                }
            }
        }
    }
}

class AlartWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = AlartWidget()
}
