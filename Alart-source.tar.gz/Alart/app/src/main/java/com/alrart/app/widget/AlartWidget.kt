package com.alrart.app.widget

import android.content.Context
import android.content.Intent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceModifier
import androidx.glance.ExperimentalGlanceApi
import androidx.glance.LocalSize
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.alrart.app.MainActivity
import com.alrart.app.R
import com.alrart.app.data.AlartDatabase
import com.alrart.app.domain.AlarmTime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Responsive Alart-branded home-screen widget with a live next-alarm summary. */
class AlartWidget : GlanceAppWidget() {
    override val sizeMode = SizeMode.Responsive(
        setOf(DpSize(180.dp, 100.dp), DpSize(250.dp, 150.dp), DpSize(320.dp, 190.dp))
    )

    @OptIn(ExperimentalGlanceApi::class)
    override suspend fun provideGlance(context: Context, id: androidx.glance.GlanceId) {
        val upcoming = withContext(Dispatchers.IO) {
            val now = LocalDateTime.now()
            AlartDatabase.get(context).alarmDao().enabled()
                .mapNotNull { alarm -> AlarmTime.nextOccurrence(alarm, now)?.let { alarm to it } }
                .sortedBy { it.second }
                .take(3)
        }
        val launchIntent = Intent(context, MainActivity::class.java)
        val noAlarm = context.getString(R.string.widget_no_alarm)
        val emptyHint = context.getString(R.string.widget_empty_hint)
        val nextLabel = context.getString(R.string.widget_next_alarm)
        val dateLabel = LocalDate.now().format(DateTimeFormatter.ofPattern("EEE · d MMM", Locale.getDefault()))

        provideContent {
            val size = LocalSize.current
            val expanded = size.width >= 245.dp && size.height >= 145.dp
            val first = upcoming.firstOrNull()
            val remaining = first?.second?.let { trigger ->
                val minutes = Duration.between(Instant.now(), Instant.ofEpochMilli(trigger)).toMinutes().coerceAtLeast(0)
                val hours = minutes / 60
                val mins = minutes % 60
                if (hours > 0) String.format(Locale.getDefault(), "%d:%02d", hours, mins)
                else context.getString(R.string.time_left, "$mins ${context.getString(R.string.minutes)}")
            }

            val background = ColorProvider(Color(0xFF130907))
            val surface = ColorProvider(Color(0xFF2A1510))
            val foreground = ColorProvider(Color(0xFFFFF7F2))
            val muted = ColorProvider(Color(0xFFE2C9BC))
            val orange = ColorProvider(Color(0xFFFF8A32))
            val yellow = ColorProvider(Color(0xFFFFC400))
            val red = ColorProvider(Color(0xFFE32636))

            Column(
                modifier = GlanceModifier.fillMaxSize()
                    .background(background)
                    .cornerRadius(28.dp)
                    .padding(if (expanded) 17.dp else 13.dp)
                    .clickable(actionStartActivity(launchIntent)),
                verticalAlignment = Alignment.Vertical.CenterVertically,
                horizontalAlignment = Alignment.Horizontal.Start
            ) {
                Row(modifier = GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.Vertical.CenterVertically) {
                    Text("ALART", style = TextStyle(color = orange, fontSize = 12.sp, fontWeight = FontWeight.Bold))
                    Spacer(GlanceModifier.width(8.dp))
                    Text("•", style = TextStyle(color = red, fontSize = 12.sp, fontWeight = FontWeight.Bold))
                    Spacer(GlanceModifier.width(6.dp))
                    Text(
                        if (first == null) context.getString(R.string.widget_ready) else nextLabel.uppercase(Locale.getDefault()),
                        style = TextStyle(color = muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    )
                }
                Spacer(GlanceModifier.height(7.dp))

                Row(modifier = GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.Vertical.CenterVertically) {
                    Text(
                        first?.let { String.format(Locale.getDefault(), "%02d:%02d", it.first.hour, it.first.minute) } ?: "--:--",
                        style = TextStyle(color = foreground, fontSize = if (expanded) 42.sp else 34.sp, fontWeight = FontWeight.Bold)
                    )
                    Spacer(GlanceModifier.width(9.dp))
                    if (remaining != null) {
                        Column(
                            modifier = GlanceModifier.background(surface).cornerRadius(14.dp).padding(horizontal = 9.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.Vertical.CenterVertically
                        ) {
                            Text(remaining, style = TextStyle(color = yellow, fontSize = 12.sp, fontWeight = FontWeight.Bold))
                            if (expanded) Text(context.getString(R.string.widget_left).uppercase(Locale.getDefault()), style = TextStyle(color = muted, fontSize = 8.sp, fontWeight = FontWeight.Medium))
                        }
                    }
                }

                Text(
                    first?.first?.title?.ifBlank { noAlarm } ?: noAlarm,
                    style = TextStyle(color = muted, fontSize = 11.sp, fontWeight = FontWeight.Medium),
                    maxLines = 1
                )

                if (expanded) {
                    Spacer(GlanceModifier.height(10.dp))
                    Row(
                        modifier = GlanceModifier.fillMaxWidth()
                            .background(surface)
                            .cornerRadius(16.dp)
                            .padding(horizontal = 11.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.Vertical.CenterVertically
                    ) {
                        if (upcoming.size > 1) {
                            upcoming.drop(1).take(2).forEachIndexed { index, entry ->
                                Column(modifier = GlanceModifier.width(98.dp)) {
                                    Text(
                                        String.format(Locale.getDefault(), "%02d:%02d", entry.first.hour, entry.first.minute),
                                        style = TextStyle(color = if (index == 0) orange else yellow, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    )
                                    Text(entry.first.title.ifBlank { nextLabel }, style = TextStyle(color = muted, fontSize = 9.sp), maxLines = 1)
                                }
                                if (index == 0 && upcoming.size > 2) Spacer(GlanceModifier.width(10.dp))
                            }
                        } else {
                            Text(emptyHint, style = TextStyle(color = muted, fontSize = 10.sp), maxLines = 2)
                        }
                    }
                }

                Spacer(GlanceModifier.height(8.dp))
                Row(modifier = GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.Vertical.CenterVertically) {
                    Text(dateLabel.uppercase(Locale.getDefault()), style = TextStyle(color = muted, fontSize = 8.sp, fontWeight = FontWeight.Bold))
                    Spacer(GlanceModifier.width(8.dp))
                    Text(context.getString(R.string.widget_open).uppercase(Locale.getDefault()), style = TextStyle(color = orange, fontSize = 9.sp, fontWeight = FontWeight.Bold))
                }
            }
        }
    }
}

class AlartWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = AlartWidget()
}
